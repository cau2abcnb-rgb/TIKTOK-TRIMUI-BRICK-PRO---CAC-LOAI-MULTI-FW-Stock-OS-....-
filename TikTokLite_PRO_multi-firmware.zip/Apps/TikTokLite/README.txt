TikTok By Cau2abc - Trimui Brick Pro   (v6.6)
=============================================
CAI DAT: xoa ban cu, chep thu muc TikTokLite vao /mnt/SDCARD/Apps/ . Can WiFi.
Tu dong tim python3 (Apps/tctmusic/pyruntime) va mpv (RomCloud, WPE...).

KHOI DONG: man hinh mo dau 5 giay "TikTok By Cau2abc - Trimui Brick Pro" (tat/bat trong Cai dat > Giao dien).

DIEU KHIEN
  Can trai/phai      Tua 5s           Can len/xuong, L2/R2  Video truoc/sau
  A  Tam dung/phat   X  Thich (tim)   L1  Binh luan         R1  Tac gia (theo doi, tai, chia se)
  Y  Menu chinh      Start  Tim kiem (ban phim Telex tieng Viet)
  Select  Tro giup   Select+L2 Tai lai   Select+X Theo doi nhanh   Select+A Tat tieng
  Can phai len/xuong Am luong      B hoac Menu (2 lan)  Thoat

CHUC NANG: Danh cho ban, Dang theo doi, Kham pha chu de, Tim kiem (tu khoa / @tacgia / #hashtag),
  Da thich, Lich su xem, Binh luan, Ho so tac gia, Tai video ve /mnt/SDCARD/Downloads/TikTok,
  Chia se link (data/links.txt). Du lieu luu trong thu muc data/.
CAI DAT (Y > Cai dat): Video (xoay, khung hinh, do sang, tuong phan, bao hoa, gamma, toc do, chat luong,
  hieu nang, am luong), Giao dien (mau, che do Toi/Sang/AMOLED, do dam bang, co chu, kieu HUD),
  Nguon video (khu vuc, chu de, xao tron, bo qua da xem), Du lieu.

GHI CHU: mpv tren may khong nap duoc Lua nen toan bo giao dien duoc ve bang Python (pygame hoac Pillow,
  font Roboto kem theo, ho tro day du tieng Viet). Khong dang nhap duoc tai khoan TikTok that:
  "Thich" va "Theo doi" luu tren may. Loi: xem /mnt/SDCARD/tiktok_debug.log (dong "ui:" ghi backend ve giao dien).
Ep kieu hinh: tao file vo.txt chua 1 tu: sdl / fbdev / drm / gpu. Nut sai: tao padmap.txt ("btn 1 = a").

v6.2: timeout 30s, thu lai nhieu lan, log loi chi tiet (dong "api:" trong tiktok_debug.log), luu 40 video gan nhat de van xem duoc khi tikwm.com khong phan hoi.
v6.3: viet binh luan - mo Binh luan (L1) roi nhan X (hoac Start): ban phim Telex, A go, Start gui. R1 xoa binh luan cua ban.
  Luu y: khong dang nhap duoc TikTok nen binh luan CHI luu tren may (data/comments.json), hien dau danh sach cua video do.
v6.4: cuon nhanh hon - Cai dat > Video > "Chuyen nhanh sau": tu chuyen sang video ke tiep sau 4/6/10/15 giay (can bat "Tu chuyen video khi het"). Tai truoc 6 video (2 luong song song), nap them danh sach som hon nen khong phai cho khi cuon lien tuc.

v6.6: khoi dong khi WiFi cham: man hinh logo KHONG dung hinh nua - sau 5 giay logo van chay va hien trang thai
  ("dang ket noi WiFi", "cho DNS", "may chu chua phan hoi"), tu thu lai toi da 90 giay, khong khoi dong lai logo.
  Neu van that bai: man hinh "Mat ket noi" > "Thu lai (cho WiFi)". Co DNS du phong (1.1.1.1 / 8.8.8.8) khi DNS may bi cham/trong.
