# -*- coding: utf-8 -*-
"""api.py - TikTok data through the public TikWM API (feed, search, creator, comments).

TikWM allows ~1 request / second, so every call goes through a global throttle
and is retried when the API answers with its rate-limit message.
"""
import os, sys, re, json, time, ssl, random, threading, urllib.request, urllib.parse, urllib.error

BASE = "https://www.tikwm.com"
UA = ("Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120.0.0.0 Mobile Safari/537.36")
try:
    CTX = ssl._create_unverified_context()
except AttributeError:
    CTX = None

_lock = threading.Lock()
_last = [0.0]
LAST_ERROR = [""]


def _log(msg):
    """goes to stderr -> launch.sh appends it to tiktok.log (copied to /mnt/SDCARD/tiktok_debug.log)"""
    try:
        sys.stderr.write("api: %s\n" % msg); sys.stderr.flush()
    except Exception:
        pass


def _http(url, data=None, timeout=20):
    h = {"User-Agent": UA, "Accept": "application/json, text/plain, */*",
         "Accept-Language": "vi-VN,vi;q=0.9,en;q=0.5", "Referer": BASE + "/", "Origin": BASE,
         "X-Requested-With": "XMLHttpRequest"}
    body = None
    if data is not None:
        body = urllib.parse.urlencode(data).encode()
        h["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8"
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
        return r.read().decode("utf-8", "ignore")


def call(path, params, tries=3):
    """-> data (dict/list) or None.  Throttled, GET first then POST (some paths answer 403 to GET)."""
    url = BASE + "/api/" + path
    for attempt in range(tries):
        with _lock:
            wait = 1.15 - (time.time() - _last[0])
            if wait > 0:
                time.sleep(wait)
            txt = None
            t0 = time.time()
            for method in ("GET", "POST"):
                try:
                    if method == "GET":
                        txt = _http(url + "?" + urllib.parse.urlencode(params))
                    else:
                        txt = _http(url, data=params)
                    break
                except urllib.error.HTTPError as e:
                    LAST_ERROR[0] = "HTTP %s" % e.code
                    _log("%s /api/%s -> HTTP %s (try %d, %.1fs)" % (method, path, e.code, attempt + 1, time.time() - t0))
                except Exception as e:
                    LAST_ERROR[0] = ("%s: %s" % (type(e).__name__, e))[:80]
                    _log("%s /api/%s -> %s: %s (try %d, %.1fs)" % (method, path, type(e).__name__, e, attempt + 1, time.time() - t0))
                    break
            _last[0] = time.time()
        if not txt:
            time.sleep(1.5 * (attempt + 1)); continue      # back off: 1.5s, 3s, 4.5s...
        try:
            res = json.loads(txt)
        except Exception:
            LAST_ERROR[0] = "bad json (chan/Cloudflare?)"
            _log("/api/%s -> not JSON: %r" % (path, txt[:80]))
            time.sleep(1.5 * (attempt + 1)); continue
        if res.get("code") == 0:
            return res.get("data")
        msg = str(res.get("msg", ""))
        LAST_ERROR[0] = msg[:80]
        _log("/api/%s -> code=%s msg=%s" % (path, res.get("code"), msg[:100]))
        if "limit" in msg.lower() or "second" in msg.lower():
            time.sleep(1.3 + attempt); continue
        return None
    return None


# ------------------------------------------------------------------ offline cache of the last good feed
CACHE_MAX = 40


def _cache_save(region, vids):
    try:
        import store
        old = store.load("feed_cache.json", {})
        cur = old.get(region) or []
        ids = {v["id"] for v in vids}
        merged = vids + [v for v in cur if v.get("id") not in ids]
        old[region] = merged[:CACHE_MAX]
        store.save("feed_cache.json", old)
    except Exception as e:
        _log("cache save failed: %r" % (e,))


def _cache_load(region, seen, want):
    try:
        import store
        cur = list((store.load("feed_cache.json", {}) or {}).get(region) or [])
    except Exception:
        return []
    random.shuffle(cur)
    fresh = [v for v in cur if v.get("id") not in (seen or ())]
    return (fresh or cur)[:want]


# ------------------------------------------------------------------ normalise
def _abs(u):
    if not u:
        return ""
    return BASE + u if u.startswith("/") else u


def norm(it):
    """raw tikwm item -> compact dict used by the UI. None if it is not a playable video."""
    if not isinstance(it, dict):
        return None
    if it.get("images"):          # photo slideshow
        return None
    play = _abs(it.get("play") or it.get("wmplay"))
    if not play:
        return None
    a = it.get("author") or {}
    m = it.get("music_info") or {}
    vid = str(it.get("video_id") or it.get("id") or "")
    uid = a.get("unique_id") or a.get("uniqueId") or ""
    title = (it.get("title") or "").strip()
    return {
        "id": vid, "title": title, "uid": uid, "nick": a.get("nickname") or uid,
        "author_id": str(a.get("id") or ""), "avatar": _abs(a.get("avatar")),
        "cover": _abs(it.get("cover") or it.get("origin_cover")),
        "play": play, "hdplay": _abs(it.get("hdplay")),
        "music": (m.get("title") or "") + ((" - " + m.get("author")) if m.get("author") else ""),
        "duration": it.get("duration") or 0,
        "likes": it.get("digg_count") or 0, "comments": it.get("comment_count") or 0,
        "shares": it.get("share_count") or 0, "views": it.get("play_count") or 0,
        "region": it.get("region") or "",
        "page_url": "https://www.tiktok.com/@%s/video/%s" % (uid or "u", vid),
    }


def _list(data):
    if isinstance(data, dict):
        data = data.get("videos") or data.get("list") or []
    out = []
    for it in data or []:
        v = norm(it)
        if v and v["id"]:
            out.append(v)
    return out


# ------------------------------------------------------------------ vietnamese filter
_VI = re.compile(r'[àáảãạâầấẩẫậăằắẳẵặèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ]', re.I)
_VIW = set("nhac che hay viet nam vn xuhuong hai cuoi tinh hat khuc nguoi gia dinh ban toi tao minh chuc mung "
           "sinh tet dam huong dan cach lam an uong mon ngon khoe dep gai trai xinh thuong con bo me anh em "
           "di ve cho den mot".split())


def is_vi(v):
    if (v.get("region") or "").upper() == "VN":
        return True
    t = v.get("title") or ""
    if _VI.search(t):
        return True
    ws = re.findall(r"\w+", t.lower())
    return sum(1 for w in ws if w in _VIW) >= 2


# ------------------------------------------------------------------ feeds
def trending(region="vietnam", count=12, want=12, tries=4, seen=None):
    """Random trending batch. Several calls are merged until `want` videos (VN filter applied)."""
    reg = "VN" if region == "vietnam" else "US"
    got, ids = [], set(seen or ())
    raw_all = []
    for _ in range(tries):
        vids = _list(call("feed/list", {"region": reg, "count": count}))
        raw_all += vids
        for v in vids:
            if v["id"] in ids:
                continue
            if region == "vietnam" and not is_vi(v):
                continue
            ids.add(v["id"]); got.append(v)
        if len(got) >= want:
            break
    if not got and raw_all:
        got = [v for v in raw_all if v["id"] not in (seen or ())][:want]
    if got:
        _cache_save(reg, got)
    else:
        got = _cache_load(reg, seen, want)
        if got:
            _log("tikwm unreachable -> using %d cached videos" % len(got))
            LAST_ERROR[0] = "offline: dung video da luu"
    return got


def search(keyword, cursor=0, count=12, region="all"):
    """-> (videos, next_cursor, has_more)"""
    kw = keyword.strip()
    if region == "vietnam" and not re.search(r"\b(vn|vietnam|việt nam)\b", kw, re.I):
        kw2 = kw + " Việt Nam"
    else:
        kw2 = kw
    data = call("feed/search", {"keywords": kw2, "count": count, "cursor": cursor, "HD": 1})
    if data is None and kw2 != kw:
        data = call("feed/search", {"keywords": kw, "count": count, "cursor": cursor, "HD": 1})
    vids = _list(data)
    nxt = (data or {}).get("cursor", 0) if isinstance(data, dict) else 0
    more = bool((data or {}).get("hasMore")) if isinstance(data, dict) else False
    return vids, nxt, more


def user_posts(uid, cursor=0, count=12):
    uid = uid.lstrip("@")
    data = call("user/posts", {"unique_id": "@" + uid, "count": count, "cursor": cursor, "HD": 1})
    vids = _list(data)
    nxt = (data or {}).get("cursor", 0) if isinstance(data, dict) else 0
    more = bool((data or {}).get("hasMore")) if isinstance(data, dict) else False
    return vids, nxt, more


def user_info(uid):
    data = call("user/info", {"unique_id": "@" + uid.lstrip("@")})
    if not isinstance(data, dict):
        return None
    u, s = data.get("user") or {}, data.get("stats") or {}
    return {"uid": u.get("uniqueId") or uid, "nick": u.get("nickname") or uid,
            "bio": u.get("signature") or "", "verified": bool(u.get("verified")),
            "followers": s.get("followerCount", 0), "following": s.get("followingCount", 0),
            "likes": s.get("heartCount", s.get("heart", 0)), "videos": s.get("videoCount", 0)}


def resolve(v):
    """Fresh playable links for a stored video (links of saved videos may expire)."""
    data = call("", {"url": v.get("page_url") or ("https://www.tiktok.com/@%s/video/%s" % (v.get("uid") or "u", v["id"])), "hd": 1})
    if isinstance(data, dict):
        n = norm(data)
        if n:
            return n
    return v


def comments(v, cursor=0, count=20):
    """-> (list of {user, text, likes, replies}, next_cursor, has_more)"""
    data = None
    for params in ({"url": v.get("page_url") or v["id"], "count": count, "cursor": cursor},
                   {"url": str(v["id"]), "count": count, "cursor": cursor},
                   {"id": str(v["id"]), "count": count, "cursor": cursor}):
        data = call("comment/list", params, tries=2)
        if data:
            break
    items = []
    if isinstance(data, dict):
        items = data.get("comments") or data.get("list") or []
    elif isinstance(data, list):
        items = data
    out = []
    for c in items:
        u = c.get("user") or {}
        out.append({"user": u.get("nickname") or u.get("unique_id") or "Ẩn danh",
                    "text": (c.get("text") or "").strip(), "likes": c.get("digg_count") or 0,
                    "replies": c.get("reply_total") or 0})
    nxt = data.get("cursor", 0) if isinstance(data, dict) else 0
    more = bool(data.get("hasMore")) if isinstance(data, dict) else False
    return out, nxt, more


# ------------------------------------------------------------------ download
def download(url, dest, progress=None, referer=None):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": referer or BASE + "/", "Accept": "*/*"})
    part = dest + ".part"
    with urllib.request.urlopen(req, timeout=20, context=CTX) as r, open(part, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            c = r.read(65536)
            if not c:
                break
            f.write(c); got += len(c)
            if progress and total:
                progress(got / total)
    if os.path.getsize(part) < 1024:
        os.remove(part); raise IOError("file rong")
    os.replace(part, dest)
    return dest
