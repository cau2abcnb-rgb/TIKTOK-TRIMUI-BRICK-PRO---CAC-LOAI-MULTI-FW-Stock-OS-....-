# -*- coding: utf-8 -*-
"""gfx.py - draws the whole TikTok Lite interface into BGRA bitmaps for mpv.

mpv on the handheld has no Lua / libass, so the UI is drawn here with the
bundled Roboto font (full Vietnamese coverage) and pushed to mpv through the
`overlay-add` IPC command.  Backends: pygame (preferred), Pillow (fallback).
Text is always sanitised against the font's real glyph table, so there are
never "tofu" boxes (emoji / unsupported symbols are dropped).
"""
import os, sys, math, bisect, unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_PATH = os.path.join(HERE, "fonts", "Roboto-Regular.ttf")
SS = 4  # supersampling for icons


# ---------------------------------------------------------------- glyph filter
class Glyphs:
    def __init__(self):
        self.starts, self.ends = [], []
        p = os.path.join(HERE, "fonts", "glyphs.txt")
        try:
            for line in open(p):
                a, b = line.strip().split("-")
                self.starts.append(int(a, 16)); self.ends.append(int(b, 16))
        except Exception:
            self.starts, self.ends = [32, 0xA0, 0x100, 0x1E00], [0x7E, 0x24F, 0x17F, 0x1EFF]

    def has(self, cp):
        i = bisect.bisect_right(self.starts, cp) - 1
        return i >= 0 and cp <= self.ends[i]

    def clean(self, text):
        if text is None:
            return ""
        text = str(text)
        text = unicodedata.normalize("NFC", text)
        rep = {"\u2192": "->", "\u2190": "<-", "\u2665": "", "\u2764": "", "\u2713": "", "\u266b": "", "\u266a": "",
               "\u2605": "*", "\u2022": "\u2022", "\t": " ", "\n": " ", "\r": " "}
        out = []
        for ch in text:
            if ch in rep:
                out.append(rep[ch]); continue
            cp = ord(ch)
            if cp < 32 or cp in (0x200B, 0x200C, 0x200D, 0xFE0F, 0xFEFF):
                continue
            if cp > 0xFFFF or not self.has(cp):
                continue
            out.append(ch)
        s = "".join(out)
        while "  " in s:
            s = s.replace("  ", " ")
        return s.strip()


GLYPHS = Glyphs()
clean = GLYPHS.clean


def fmt_num(n):
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1000000000:
        return ("%.1f" % (n / 1e9)).replace(".", ",").replace(",0", "") + "B"
    if n >= 1000000:
        return ("%.1f" % (n / 1e6)).replace(".", ",").replace(",0", "") + "M"
    if n >= 10000:
        return ("%d" % (n // 1000)) + "K"
    if n >= 1000:
        return ("%.1f" % (n / 1e3)).replace(".", ",").replace(",0", "") + "K"
    return str(n)


# ---------------------------------------------------------------- icons (unit square)
def _heart_pts(n=60):
    pts = []
    for i in range(n):
        t = 2 * math.pi * i / n
        x = 16 * math.sin(t) ** 3
        y = -(13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t))
        pts.append((0.5 + x / 38.0, 0.47 + y / 38.0))
    return pts


HEART = _heart_pts()


def draw_icon(p, name, color):
    """p: painter working on a unit square (0..1)."""
    if name == "heart":
        p.polygon(HEART, color)
    elif name == "comment":
        p.rrect(0.1, 0.12, 0.8, 0.6, 0.2, color)
        p.polygon([(0.3, 0.65), (0.28, 0.92), (0.55, 0.68)], color)
    elif name == "share":
        p.polygon([(0.92, 0.45), (0.55, 0.12), (0.55, 0.32), (0.12, 0.42), (0.12, 0.88), (0.2, 0.7),
                   (0.55, 0.62), (0.55, 0.8)], color)
    elif name == "save":
        p.polygon([(0.22, 0.08), (0.78, 0.08), (0.78, 0.94), (0.5, 0.72), (0.22, 0.94)], color)
    elif name == "download":
        p.polygon([(0.38, 0.08), (0.62, 0.08), (0.62, 0.42), (0.82, 0.42), (0.5, 0.78), (0.18, 0.42), (0.38, 0.42)], color)
        p.rect(0.15, 0.86, 0.7, 0.09, color)
    elif name == "plus":
        p.rect(0.43, 0.15, 0.14, 0.7, color)
        p.rect(0.15, 0.43, 0.7, 0.14, color)
    elif name == "check":
        p.line([(0.15, 0.55), (0.4, 0.8), (0.86, 0.22)], 0.14, color)
    elif name == "play":
        p.polygon([(0.2, 0.1), (0.2, 0.9), (0.88, 0.5)], color)
    elif name == "pause":
        p.rect(0.2, 0.12, 0.2, 0.76, color)
        p.rect(0.6, 0.12, 0.2, 0.76, color)
    elif name == "note":
        p.ellipse(0.1, 0.62, 0.34, 0.26, color)
        p.rect(0.36, 0.1, 0.11, 0.66, color)
        p.polygon([(0.36, 0.1), (0.9, 0.3), (0.9, 0.52), (0.36, 0.34)], color)
    elif name == "speaker":
        p.polygon([(0.1, 0.38), (0.32, 0.38), (0.56, 0.16), (0.56, 0.84), (0.32, 0.62), (0.1, 0.62)], color)
        p.line([(0.7, 0.35), (0.78, 0.5), (0.7, 0.65)], 0.07, color)
        p.line([(0.8, 0.22), (0.92, 0.5), (0.8, 0.78)], 0.07, color)
    elif name == "mute":
        p.polygon([(0.1, 0.38), (0.32, 0.38), (0.56, 0.16), (0.56, 0.84), (0.32, 0.62), (0.1, 0.62)], color)
        p.line([(0.68, 0.36), (0.92, 0.64)], 0.08, color)
        p.line([(0.92, 0.36), (0.68, 0.64)], 0.08, color)
    elif name == "search":
        p.ring(0.1, 0.1, 0.55, 0.11, color)
        p.line([(0.6, 0.6), (0.9, 0.9)], 0.13, color)
    elif name == "gear":
        for i in range(8):
            a = i * math.pi / 4
            cx, cy = 0.5 + 0.36 * math.cos(a), 0.5 + 0.36 * math.sin(a)
            p.ellipse(cx - 0.09, cy - 0.09, 0.18, 0.18, color)
        p.ring(0.2, 0.2, 0.6, 0.16, color)
    elif name == "user":
        p.ellipse(0.3, 0.1, 0.4, 0.4, color)
        p.rrect(0.14, 0.56, 0.72, 0.38, 0.2, color)
    elif name == "arrow":
        p.polygon([(0.3, 0.1), (0.8, 0.5), (0.3, 0.9)], color)
    elif name == "star":
        pts = []
        for i in range(10):
            r = 0.46 if i % 2 == 0 else 0.2
            a = -math.pi / 2 + i * math.pi / 5
            pts.append((0.5 + r * math.cos(a), 0.55 + r * math.sin(a)))
        p.polygon(pts, color)


# ---------------------------------------------------------------- base canvas
class Canvas:
    w = h = 0

    def wrap(self, text, size, maxw, maxlines=99, bold=False):
        text = clean(text)
        if not text:
            return []
        words, lines, cur = text.split(" "), [], ""
        i = 0
        while i < len(words):
            w = words[i]
            t = (cur + " " + w) if cur else w
            if self.measure(t, size, bold)[0] <= maxw:
                cur = t; i += 1
            else:
                if not cur:  # single long word
                    k = len(w)
                    while k > 1 and self.measure(w[:k], size, bold)[0] > maxw:
                        k -= 1
                    lines.append(w[:k]); words[i] = w[k:] or ""
                    if not words[i]:
                        i += 1
                else:
                    lines.append(cur); cur = ""
            if len(lines) >= maxlines:
                break
        if cur and len(lines) < maxlines:
            lines.append(cur)
        if len(lines) >= maxlines and (i < len(words) or cur):
            last = lines[maxlines - 1]
            while last and self.measure(last + "...", size, bold)[0] > maxw:
                last = last[:-1]
            lines = lines[:maxlines - 1] + [last.rstrip() + "..."]
        return lines[:maxlines]

    def fit(self, text, size, maxw, bold=False):
        text = clean(text)
        if self.measure(text, size, bold)[0] <= maxw:
            return text
        while text and self.measure(text + "...", size, bold)[0] > maxw:
            text = text[:-1]
        return text.rstrip() + "..."

    def icon(self, name, x, y, size, color):
        self._icon(name, x, y, size, color)


# ---------------------------------------------------------------- pygame backend
class PygameCanvas(Canvas):
    fonts = {}

    def __init__(self, w, h):
        import pygame
        self.pg = pygame
        self.w, self.h = w, h
        self.s = pygame.Surface((w, h), pygame.SRCALPHA, 32)
        self.s.fill((0, 0, 0, 0))

    @classmethod
    def init(cls):
        import pygame
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        pygame.font.init()
        return True

    def _font(self, size, bold):
        k = (int(size), bool(bold))
        f = self.fonts.get(k)
        if f is None:
            f = self.pg.font.Font(FONT_PATH, int(size))
            if bold:
                try: f.set_bold(True)
                except Exception: pass
            self.fonts[k] = f
        return f

    def clear(self, color=(0, 0, 0, 0)):
        self.s.fill(color)

    def rect(self, x, y, w, h, color, radius=0):
        if w < 1 or h < 1:
            return
        r = self.pg.Rect(int(x), int(y), int(w), int(h))
        if radius > 0:
            self.pg.draw.rect(self.s, color, r, border_radius=int(min(radius, r.w // 2, r.h // 2)))
        else:
            self.s.fill(color, r)

    def circle(self, cx, cy, r, color):
        self._icon_shape(cx - r, cy - r, 2 * r, lambda p: p.ellipse(0, 0, 1, 1, color))

    def text(self, x, y, text, size, color, bold=False, anchor="l"):
        text = clean(text)
        if not text:
            return 0
        surf = self._font(size, bold).render(text, True, color[:3])
        if len(color) > 3 and color[3] < 255:
            surf.set_alpha(color[3])
        w = surf.get_width()
        if anchor == "c":
            x -= w // 2
        elif anchor == "r":
            x -= w
        self.s.blit(surf, (int(x), int(y)))
        return w

    def measure(self, text, size, bold=False):
        text = clean(text)
        return self._font(size, bold).size(text) if text else (0, int(size * 1.2))

    class _P:
        def __init__(self, pg, surf, scale):
            self.pg, self.s, self.k = pg, surf, scale

        def _c(self, c): return c
        def polygon(self, pts, color):
            self.pg.draw.polygon(self.s, color, [(x * self.k, y * self.k) for x, y in pts])
        def rect(self, x, y, w, h, color):
            self.pg.draw.rect(self.s, color, (x * self.k, y * self.k, max(1, w * self.k), max(1, h * self.k)))
        def rrect(self, x, y, w, h, r, color):
            self.pg.draw.rect(self.s, color, (x * self.k, y * self.k, w * self.k, h * self.k), border_radius=int(r * self.k))
        def ellipse(self, x, y, w, h, color):
            if color is None: return
            self.pg.draw.ellipse(self.s, color, (x * self.k, y * self.k, max(1, w * self.k), max(1, h * self.k)))
        def ring(self, x, y, d, t, color):
            self.pg.draw.ellipse(self.s, color, (x * self.k, y * self.k, d * self.k, d * self.k), max(1, int(t * self.k)))
        def line(self, pts, wd, color):
            self.pg.draw.lines(self.s, color, False, [(a * self.k, b * self.k) for a, b in pts], max(1, int(wd * self.k)))
            for a, b in pts:
                r = wd * self.k / 2
                self.pg.draw.circle(self.s, color, (int(a * self.k), int(b * self.k)), max(1, int(r)))

    def _icon_shape(self, x, y, size, fn):
        size = max(2, int(size))
        big = self.pg.Surface((size * SS, size * SS), self.pg.SRCALPHA, 32)
        big.fill((0, 0, 0, 0))
        fn(self._P(self.pg, big, size * SS))
        small = self.pg.transform.smoothscale(big, (size, size))
        self.s.blit(small, (int(x), int(y)))

    def _icon(self, name, x, y, size, color):
        self._icon_shape(x, y, size, lambda p: draw_icon(p, name, color))

    def to_bgra(self):
        rgba = bytearray(self.pg.image.tostring(self.s, "RGBA"))
        r = rgba[0::4]
        rgba[0::4] = rgba[2::4]
        rgba[2::4] = r
        return bytes(rgba)

    def save_png(self, path):
        self.pg.image.save(self.s, path)


# ---------------------------------------------------------------- Pillow backend
class PilCanvas(Canvas):
    fonts = {}

    def __init__(self, w, h):
        from PIL import Image, ImageDraw
        self.Image, self.ImageDraw = Image, ImageDraw
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    @classmethod
    def init(cls):
        try:
            import PIL  # noqa
        except ImportError:
            pl = os.path.join(HERE, "pylib")
            if os.path.isdir(pl):
                sys.path.append(pl)
            import PIL  # noqa
        return True

    def _font(self, size):
        from PIL import ImageFont
        k = int(size)
        f = self.fonts.get(k)
        if f is None:
            f = ImageFont.truetype(FONT_PATH, k)
            self.fonts[k] = f
        return f

    def clear(self, color=(0, 0, 0, 0)):
        self.im.paste(color, (0, 0, self.w, self.h))

    def rect(self, x, y, w, h, color, radius=0):
        if w < 1 or h < 1:
            return
        box = [int(x), int(y), int(x + w - 1), int(y + h - 1)]
        if radius > 0:
            self.d.rounded_rectangle(box, radius=int(min(radius, w // 2, h // 2)), fill=color)
        else:
            self.d.rectangle(box, fill=color)

    def circle(self, cx, cy, r, color):
        self._icon_shape(cx - r, cy - r, 2 * r, lambda p: p.ellipse(0, 0, 1, 1, color))

    def text(self, x, y, text, size, color, bold=False, anchor="l"):
        text = clean(text)
        if not text:
            return 0
        f = self._font(size)
        w = int(self.d.textlength(text, font=f)) + (1 if bold else 0)
        if anchor == "c":
            x -= w // 2
        elif anchor == "r":
            x -= w
        kw = {"stroke_width": 1, "stroke_fill": color} if bold else {}
        self.d.text((int(x), int(y) - 2), text, font=f, fill=color, **kw)
        return w

    def measure(self, text, size, bold=False):
        text = clean(text)
        f = self._font(size)
        return (int(self.d.textlength(text, font=f)) + (1 if bold else 0), int(size * 1.2)) if text else (0, int(size * 1.2))

    class _P:
        def __init__(self, d, scale):
            self.d, self.k = d, scale
        def polygon(self, pts, color):
            self.d.polygon([(x * self.k, y * self.k) for x, y in pts], fill=color)
        def rect(self, x, y, w, h, color):
            self.d.rectangle([x * self.k, y * self.k, (x + w) * self.k, (y + h) * self.k], fill=color)
        def rrect(self, x, y, w, h, r, color):
            self.d.rounded_rectangle([x * self.k, y * self.k, (x + w) * self.k, (y + h) * self.k], radius=r * self.k, fill=color)
        def ellipse(self, x, y, w, h, color):
            if color is None: return
            self.d.ellipse([x * self.k, y * self.k, (x + w) * self.k, (y + h) * self.k], fill=color)
        def ring(self, x, y, dia, t, color):
            self.d.ellipse([x * self.k, y * self.k, (x + dia) * self.k, (y + dia) * self.k], outline=color, width=max(1, int(t * self.k)))
        def line(self, pts, wd, color):
            self.d.line([(a * self.k, b * self.k) for a, b in pts], fill=color, width=max(1, int(wd * self.k)), joint="curve")
            r = wd * self.k / 2
            for a, b in pts:
                self.d.ellipse([a * self.k - r, b * self.k - r, a * self.k + r, b * self.k + r], fill=color)

    def _icon_shape(self, x, y, size, fn):
        size = max(2, int(size))
        big = self.Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
        fn(self._P(self.ImageDraw.Draw(big), size * SS))
        small = big.resize((size, size), self.Image.LANCZOS)
        self.im.alpha_composite(small, (max(0, int(x)), max(0, int(y)))) if x >= 0 and y >= 0 else self.im.paste(small, (int(x), int(y)), small)

    def _icon(self, name, x, y, size, color):
        self._icon_shape(x, y, size, lambda p: draw_icon(p, name, color))

    def to_bgra(self):
        r, g, b, a = self.im.split()
        return self.Image.merge("RGBA", (b, g, r, a)).tobytes()

    def save_png(self, path):
        self.im.save(path)


# ---------------------------------------------------------------- factory
BACKEND = None
BACKEND_NAME = "none"


PROBES = {
    "pygame": "import os;os.environ['SDL_VIDEODRIVER']='dummy';os.environ['SDL_AUDIODRIVER']='dummy';"
              "import pygame;pygame.font.init();f=pygame.font.Font(%r,20);s=f.render('Việt Nam',True,(255,255,255));"
              "t=pygame.Surface((64,64),pygame.SRCALPHA,32);t.blit(s,(0,0));pygame.image.tostring(t,'RGBA');"
              "pygame.transform.smoothscale(t,(32,32))",
    "pil": "import sys;sys.path.append(%r)\nfrom PIL import Image,ImageDraw,ImageFont\n"
           "f=ImageFont.truetype(%r,20);im=Image.new('RGBA',(64,64));d=ImageDraw.Draw(im);"
           "d.text((0,0),'Việt',font=f,fill=(255,255,255,255));d.rounded_rectangle([1,1,30,30],radius=4,fill=(1,2,3,255));im.tobytes()",
}


def _probe(name):
    """True if the backend imports and draws in a throw-away process (guards against segfaults)."""
    import subprocess
    code = PROBES[name] % ((FONT_PATH,) if name == "pygame" else (os.path.join(HERE, "pylib"), FONT_PATH))
    try:
        r = subprocess.run([sys.executable, "-c", code], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=25)
        if r.returncode != 0:
            PROBE_ERR[name] = (r.stderr or b"").decode("utf-8", "ignore")[-200:] or ("rc=%d" % r.returncode)
        return r.returncode == 0
    except Exception as e:
        PROBE_ERR[name] = repr(e)[:200]
        return False


PROBE_ERR = {}


def init_backend(prefer=None, probe=True):
    """Returns the Canvas class in use (pygame, then Pillow) or None."""
    global BACKEND, BACKEND_NAME
    order = [prefer] if prefer else ["pygame", "pil"]
    for name in order:
        try:
            if probe and not _probe(name):
                continue
            if name == "pygame":
                PygameCanvas.init(); BACKEND, BACKEND_NAME = PygameCanvas, "pygame"; return BACKEND
            if name == "pil":
                PilCanvas.init(); BACKEND, BACKEND_NAME = PilCanvas, "pillow"; return BACKEND
        except Exception as e:
            PROBE_ERR[name] = repr(e)[:200]
            continue
    return None


def new_canvas(w, h):
    return BACKEND(int(w), int(h))
