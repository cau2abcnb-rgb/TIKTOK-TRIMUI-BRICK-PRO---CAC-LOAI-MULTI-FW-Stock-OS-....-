#!/bin/sh
# TikTok By Cau2abc - Trimui Brick Pro - launcher
# Works from: TrimUI Stock OS, CrossMix-OS (Apps/), SpruceOS (App/ wrapper), NextUI / MinUI / Nx-Redux
# (Tools/tg5040/TikTok.pak wrapper) and KNULLI (ports wrapper). POSIX sh only (dash safe).
APPDIR="$(cd "$(dirname "$0")" && pwd)"
cd "$APPDIR" || exit 1
set -f                      # no globbing (find patterns below contain *)

###### 0. which firmware / where is the SD card? ######
FW="stock"
if [ -n "$SDCARD_PATH" ] && [ -d "$SDCARD_PATH" ]; then SDROOT="$SDCARD_PATH"
elif [ -d /mnt/SDCARD ]; then SDROOT=/mnt/SDCARD
elif [ -d /userdata ]; then SDROOT=/userdata
else SDROOT="$(dirname "$(dirname "$APPDIR")")"; fi
[ -d "$SDROOT/.system" ] && FW="minui/nextui"
[ -d "$SDROOT/spruce" ] && FW="spruce"
[ -d "$SDROOT/System/bin" ] && [ -d "$SDROOT/Apps" ] && [ -f "$SDROOT/System/usr/trimui/scripts/mainui_launch.sh" ] && FW="crossmix"
[ -d /userdata/system ] && [ -f /etc/batocera-release ] 2>/dev/null && FW="knulli"
[ -f /usr/bin/batocera-info ] && FW="knulli"
LOG="$APPDIR/tiktok.log"
DBG="$SDROOT/tiktok_debug.log"
PORT=8808
SOCK=/tmp/tiktok_mpv.sock
M3U=/tmp/tiktok.m3u
SHIM=/tmp/tiktok_bin
export TIKTOK_SAVE_DIR="$SDROOT/Downloads/TikTok"
export TIKTOK_FW="$FW" TIKTOK_SDROOT="$SDROOT"

: > "$LOG"
say() { echo "$*" >> "$LOG"; }
say "== start $(date) app=$APPDIR fw=$FW sdroot=$SDROOT"

# firmware shells export their own LD_LIBRARY_PATH / SDL variables - do not inherit them
SYS_PATH="$PATH"
unset SDL_VIDEODRIVER SDL_AUDIODRIVER SDL_GAMECONTROLLERCONFIG SDL_NOMOUSE SDL_RENDER_DRIVER
BASE_LD="/usr/trimui/lib:/usr/lib:/lib:/usr/lib64:/lib64"

# directories that never hold runtimes - skipped by find (big and slow on a full SD card)
PRUNE="-path */Roms -o -path */roms -o -path */Saves -o -path */Bios -o -path */bios -o -path */Imgs -o -path */Music -o -path */MEDIA -o -path */Downloads -o -path */Themes -o -path */.userdata -o -path */Backup -o -path */.tmp_update"

CFG="$APPDIR/data/paths.cfg"      # remembers what worked last time (skips the slow search)
mkdir -p "$APPDIR/data" 2>/dev/null
SAVED_PY=""; SAVED_MPV=""
[ -f "$CFG" ] && { SAVED_PY="$(sed -n 's/^py=//p' "$CFG")"; SAVED_MPV="$(sed -n 's/^mpv=//p' "$CFG")"; }

###### 1. find python3 (needs ssl, json, urllib, socket) ######
PY=""; PYHOME=""; PYLD=""
try_py() {   # $1 = python executable
    [ -f "$1" ] || return 1
    d="$(dirname "$1")"; root="$(dirname "$d")"
    for ld in "$root/lib:$root/libs:$APPDIR/libs:$SDROOT/Apps/tctmusic/libs:$SDROOT/Apps/tctmusic/pyruntime/libs" ""; do
        if LD_LIBRARY_PATH="$ld:$BASE_LD" PYTHONHOME="$root" "$1" -c "import ssl,json,urllib.request,socket" >/dev/null 2>&1; then
            PY="$1"; PYHOME="$root"; PYLD="$ld"; return 0
        fi
        if LD_LIBRARY_PATH="$ld:$BASE_LD" "$1" -c "import ssl,json,urllib.request,socket" >/dev/null 2>&1; then
            PY="$1"; PYHOME=""; PYLD="$ld"; return 0
        fi
    done
    return 1
}
SYSPY="$(command -v python3 2>/dev/null)"
for c in "$SAVED_PY" "$APPDIR/bin/python3" "$SDROOT/Apps/tctmusic/pyruntime/bin/python3" \
         /mnt/SDCARD/Apps/tctmusic/pyruntime/bin/python3 "$SYSPY" /usr/bin/python3 /usr/local/bin/python3 \
         "$SDROOT/.system/tg5040/bin/python3" "$SDROOT/.system/bin/python3"; do
    [ -n "$c" ] && try_py "$c" && break
done
if [ -z "$PY" ]; then
    say "python: quick list failed, searching $SDROOT ..."
    for c in $(find "$SDROOT" -maxdepth 6 \( $PRUNE \) -prune -o \( -name python3 -o -name 'python3.[0-9]*' \) -type f -print 2>/dev/null | head -n 30); do
        try_py "$c" && break
    done
fi
say "python=$PY home=$PYHOME ld=$PYLD"

###### 2. find mpv (try each candidate with --version) ######
MPV=""; MPVLD=""
try_mpv() {
    [ -f "$1" ] || return 1
    d="$(dirname "$1")"; root="$(dirname "$d")"
    for ld in "$root/lib:$d/lib:$d:$root/libs" "$d" ""; do
        if LD_LIBRARY_PATH="$ld:$BASE_LD" "$1" --version >/dev/null 2>&1; then
            MPV="$1"; MPVLD="$ld"; return 0
        fi
    done
    return 1
}
SYSMPV="$(command -v mpv 2>/dev/null)"
for c in "$SAVED_MPV" "$APPDIR/bin/mpv.real" "$APPDIR/bin/mpv" \
         "$SDROOT/Apps/RomCloud/RomCloud/bin/mpv.real" "$SDROOT/Apps/RomCloud/RomCloud/bin/mpv" \
         "$SDROOT/Apps/WPE/mpv/mpv" /mnt/SDCARD/Apps/RomCloud/RomCloud/bin/mpv.real \
         "$SYSMPV" /usr/bin/mpv /usr/local/bin/mpv "$SDROOT/.system/tg5040/bin/mpv"; do
    [ -n "$c" ] && try_mpv "$c" && break
done
if [ -z "$MPV" ]; then
    say "mpv: quick list failed, searching $SDROOT ..."
    for c in $(find "$SDROOT" -maxdepth 7 \( $PRUNE \) -prune -o \( -name mpv -o -name mpv.real -o -name 'mpv-*' \) -type f -print 2>/dev/null | head -n 30); do
        try_mpv "$c" && break
    done
fi
say "mpv=$MPV ld=$MPVLD"
[ -n "$PY" ] && [ -n "$MPV" ] && printf 'py=%s\nmpv=%s\n' "$PY" "$MPV" > "$CFG" 2>/dev/null

fail() {
    say "LOI: $*"
    cp "$LOG" "$DBG" 2>/dev/null
    if [ -n "$MPV" ] && [ -f "$APPDIR/error.jpg" ]; then
        LD_LIBRARY_PATH="$MPVLD:$BASE_LD" "$MPV" --no-config --vo="${VO_ONE:-sdl}" --ao=null \
            --image-display-duration=6 --really-quiet "$APPDIR/error.jpg" >/dev/null 2>&1
    fi
    exit 1
}
[ -n "$PY" ]  || fail "khong tim thay python3 chay duoc (copy Apps/tctmusic/pyruntime vao the nho hoac dat vao $APPDIR/bin/python3) fw=$FW"
[ -n "$MPV" ] || fail "khong tim thay mpv chay duoc (copy Apps/RomCloud vao the nho hoac dat mpv.real vao $APPDIR/bin/) fw=$FW"

###### 3. python wrapper so mpv's lua can call plain "python3" ######
rm -rf "$SHIM"; mkdir -p "$SHIM"
cat > "$SHIM/python3" <<EOS
#!/bin/sh
export LD_LIBRARY_PATH="$PYLD:$BASE_LD"
${PYHOME:+export PYTHONHOME="$PYHOME"}
export TIKTOK_PROXY_PORT=$PORT
exec "$PY" "\$@"
EOS
chmod +x "$SHIM/python3"; ln -sf "$SHIM/python3" "$SHIM/python"
export PATH="$SHIM:$SYS_PATH"
export TIKTOK_PROXY_PORT=$PORT
export HOME="$APPDIR"

###### 3b. mpv config staging: keep only options this mpv build knows ######
STAGE=/tmp/tiktok_cfg
rm -rf "$STAGE"; mkdir -p "$STAGE"
LD_LIBRARY_PATH="$MPVLD:$BASE_LD" "$MPV" --no-config --list-options 2>/dev/null \
    | awk '{print $1}' | sed 's/^--//' > "$STAGE/.opts"
: > "$STAGE/mpv.conf"
while IFS= read -r line; do
    case "$line" in ""|"#"*) continue ;; esac
    key="${line%%=*}"; key="$(echo "$key" | tr -d ' ')"
    if grep -qx -- "$key" "$STAGE/.opts" 2>/dev/null; then
        echo "$line" >> "$STAGE/mpv.conf"
    else
        say "mpv option skipped (unsupported): $key"
    fi
done < "$APPDIR/mpv.conf"
[ -s "$STAGE/.opts" ] || cp "$APPDIR/mpv.conf" "$STAGE/mpv.conf"
export MPV_HOME="$STAGE"

###### 4. clean-up on exit ######
cleanup() {
    [ -n "$MPVPID" ]   && kill "$MPVPID"   2>/dev/null
    [ -n "$PROXYPID" ] && kill "$PROXYPID" 2>/dev/null
    set +f; rm -f "$SOCK" /tmp/tt_ov*.bgra; rm -rf "$APPDIR/cache"
    cp "$LOG" "$DBG" 2>/dev/null
}
trap cleanup EXIT
trap 'exit 0' INT TERM HUP     # a signal (power menu / OS kill) ends the launcher; EXIT trap cleans up

###### 5. relay proxy (http -> https for mpv), restarted automatically if it dies ######
supervise() {
    nm="$1"; shift
    (
        child=""
        trap '[ -n "$child" ] && kill "$child" 2>/dev/null; exit 0' TERM INT
        while :; do
            "$@" >>"$LOG" 2>&1 &
            child=$!
            wait "$child"
            echo "watchdog: $nm exited, restarting" >> "$LOG"
            sleep 1
        done
    ) &
}
export TIKTOK_M3U="$M3U" TIKTOK_CACHE="$APPDIR/cache" TIKTOK_LOG="$LOG"
rm -rf "$APPDIR/cache"; mkdir -p "$APPDIR/cache" "$APPDIR/data"
supervise proxy "$SHIM/python3" "$APPDIR/proxy.py" $PORT
PROXYPID=$!

###### 6. which video output works? ######
MPVENV="LD_LIBRARY_PATH=$MPVLD:$BASE_LD"
VOS=""
[ -f "$APPDIR/vo.txt" ] && VOS="$(cat "$APPDIR/vo.txt")"
VOLIST="$(env $MPVENV "$MPV" --no-config --vo=help 2>&1)"
say "vo available: $(echo "$VOLIST" | tr '\n' ' ' | cut -c1-300)"
for v in sdl drm fbdev gpu; do
    echo "$VOLIST" | grep -q "^ *$v " && VOS="$VOS $v"
done
[ -n "$VOS" ] || VOS="sdl fbdev drm"
VO_ONE="$(echo $VOS | cut -d' ' -f1)"

###### 7. run: mpv (idle window) + ui.py (intro, menus, gamepad). ui.py exit: 0 quit, 3 mpv died ######
GOOD=""; FAST=0; RUNS=0
while [ $RUNS -lt 100 ]; do
    RUNS=$((RUNS+1))
    LIST="$GOOD"; [ -n "$LIST" ] || LIST="$VOS"
    STARTED=0
    for vo in $LIST; do
        case "$vo" in
            gpu) VOARGS="--vo=gpu --gpu-context=drm" ;;
            *)   VOARGS="--vo=$vo" ;;
        esac
        say "mpv try vo=$vo (run $RUNS)"
        rm -f "$SOCK"
        env $MPVENV "$MPV" $VOARGS --ao=alsa --fs --idle=yes --force-window=yes \
            --input-ipc-server="$SOCK" --msg-level=all=error >>"$LOG" 2>&1 &
        MPVPID=$!
        n=0; while [ $n -lt 40 ] && [ ! -S "$SOCK" ] && kill -0 "$MPVPID" 2>/dev/null; do sleep 0.1; n=$((n+1)); done
        sleep 1
        if ! kill -0 "$MPVPID" 2>/dev/null; then
            say "mpv vo=$vo died at start"; MPVPID=""; continue
        fi
        T0=$(date +%s)
        "$SHIM/python3" "$APPDIR/ui.py" "$SOCK" >>"$LOG" 2>&1
        RC=$?
        DT=$(( $(date +%s) - T0 ))
        say "ui exit=$RC after ${DT}s (vo=$vo)"
        kill "$MPVPID" 2>/dev/null; wait "$MPVPID" 2>/dev/null; MPVPID=""
        [ "$RC" = 0 ] && break 2
        [ "$RC" -ge 128 ] 2>/dev/null && break 2      # killed by a signal: do not relaunch
        if [ $DT -ge 8 ]; then GOOD="$vo"; STARTED=1; break; fi
    done
    if [ "$STARTED" = 1 ]; then FAST=0; else
        FAST=$((FAST+1))
        [ $FAST -ge 3 ] && fail "khong khoi dong duoc mpv/giao dien - xem $LOG"
    fi
    sleep 1
    [ "$(wc -c < "$LOG")" -gt 500000 ] && tail -c 100000 "$LOG" > "$LOG.tmp" && mv -f "$LOG.tmp" "$LOG"
done
exit 0
