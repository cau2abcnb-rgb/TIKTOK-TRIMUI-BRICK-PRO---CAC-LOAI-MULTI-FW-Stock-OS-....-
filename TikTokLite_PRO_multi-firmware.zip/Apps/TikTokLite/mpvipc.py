# -*- coding: utf-8 -*-
"""mpvipc.py - tiny non-blocking client for mpv's JSON IPC socket (+ bitmap overlays)."""
import os, json, socket, time, select


class Mpv:
    def __init__(self, path):
        self.path = path
        self.s = None
        self.buf = b""
        self.alive = False
        self.rid = 0
        self.cbs = {}
        self.events = []
        self.tmpdir = "/tmp"
        self.ovfile = {}
        self.flip = 0

    def connect(self, timeout=15.0):
        t0 = time.time()
        while time.time() - t0 < timeout:
            try:
                s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                s.connect(self.path)
                s.setblocking(False)
                self.s, self.alive = s, True
                return True
            except Exception:
                time.sleep(0.2)
        return False

    def fileno(self):
        return self.s.fileno() if self.s else -1

    def _send(self, obj):
        if not self.alive:
            return
        data = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
        try:
            self.s.setblocking(True)
            self.s.settimeout(1.0)
            self.s.sendall(data)
        except Exception:
            self.alive = False
        finally:
            try: self.s.setblocking(False)
            except Exception: pass

    def cmd(self, *args, cb=None):
        self.rid += 1
        if cb:
            self.cbs[self.rid] = cb
        self._send({"command": list(args), "request_id": self.rid})

    def set(self, name, value):
        self.cmd("set_property", name, value)

    def observe(self, i, name):
        self.cmd("observe_property", i, name)

    def read(self):
        """returns list of events (dicts); handles command replies internally"""
        out = []
        if not self.alive:
            return out
        try:
            while True:
                chunk = self.s.recv(65536)
                if not chunk:
                    self.alive = False; break
                self.buf += chunk
        except BlockingIOError:
            pass
        except Exception:
            self.alive = False
        while b"\n" in self.buf:
            line, self.buf = self.buf.split(b"\n", 1)
            try:
                m = json.loads(line.decode("utf-8", "ignore"))
            except Exception:
                continue
            if "event" in m:
                out.append(m)
            elif "request_id" in m:
                cb = self.cbs.pop(m["request_id"], None)
                if cb:
                    try: cb(m)
                    except Exception: pass
        return out

    # ---- overlays -------------------------------------------------------
    def overlay(self, oid, x, y, w, h, bgra, cb=None):
        self.flip ^= 1
        path = os.path.join(self.tmpdir, "tt_ov%d_%d.bgra" % (oid, self.flip))
        try:
            with open(path, "wb") as f:
                f.write(bgra)
        except Exception:
            return
        self.cmd("overlay-add", oid, int(x), int(y), path, 0, "bgra", int(w), int(h), int(w) * 4, cb=cb)

    def overlay_remove(self, oid):
        self.cmd("overlay-remove", oid)

    def close(self):
        try:
            if self.s: self.s.close()
        except Exception:
            pass
        self.alive = False
