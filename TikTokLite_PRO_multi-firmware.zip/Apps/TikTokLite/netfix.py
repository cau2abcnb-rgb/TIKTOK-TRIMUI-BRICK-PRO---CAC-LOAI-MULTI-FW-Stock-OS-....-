# -*- coding: utf-8 -*-
"""netfix.py - makes networking survive slow WiFi / broken DNS on handhelds.

* install(): replaces socket.getaddrinfo with a version that (1) never blocks more than ~4 s,
  (2) falls back to asking public DNS servers directly over UDP (1.1.1.1 / 8.8.8.8 / 9.9.9.9)
  when the system resolver is empty or slow (typical right after WiFi (re)connects),
  (3) caches answers for 10 minutes.
* status(): quick stage check -> (stage, text) for the "waiting for WiFi" screen.
* kick_wifi(): asks wpa_supplicant to reconnect (only if wpa_cli exists).
"""
import os, socket, struct, threading, time, random, subprocess, shutil

_orig = socket.getaddrinfo
_cache = {}
DNS_SERVERS = ("1.1.1.1", "8.8.8.8", "9.9.9.9", "223.5.5.5")
TEST_HOST = "www.tikwm.com"


def _is_ip(h):
    try:
        socket.inet_aton(h); return True
    except Exception:
        return ":" in h


def _udp_resolve(host, server, timeout=2.0):
    qid = random.randint(0, 65535)
    q = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0)
    q += b"".join(bytes([len(p)]) + p.encode() for p in host.split(".")) + b"\0" + struct.pack(">HH", 1, 1)
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(timeout)
        s.sendto(q, (server, 53))
        data = s.recv(1500)
    finally:
        s.close()
    rid, flags, qd, an = struct.unpack(">HHHH", data[:8])
    if rid != qid:
        return []

    def skip(pos):
        while True:
            l = data[pos]
            if l == 0: return pos + 1
            if l & 0xC0 == 0xC0: return pos + 2
            pos += 1 + l
    pos = 12
    for _ in range(qd):
        pos = skip(pos) + 4
    ips = []
    for _ in range(an):
        pos = skip(pos)
        typ, _cls, _ttl, rdl = struct.unpack(">HHIH", data[pos:pos + 10]); pos += 10
        if typ == 1 and rdl == 4:
            ips.append(socket.inet_ntoa(data[pos:pos + 4]))
        pos += rdl
    return ips


def _gai(host, port, family=0, type=0, proto=0, flags=0):
    if not isinstance(host, str) or not host or _is_ip(host) or host == "localhost":
        return _orig(host, port, family, type, proto, flags)
    now = time.time()
    c = _cache.get(host)
    ips = c[1] if (c and now - c[0] < 600) else None
    if not ips:
        box = []

        def w():
            try: box.append(_orig(host, port, family, type, proto, flags))
            except Exception as e: box.append(e)
        t = threading.Thread(target=w, daemon=True); t.start(); t.join(4.0)
        if box and not isinstance(box[0], Exception):
            res = box[0]
            v4 = [a[4][0] for a in res if a[0] == socket.AF_INET]
            if v4:
                _cache[host] = (now, v4)
            return res
        for srv in DNS_SERVERS:
            try:
                ips = _udp_resolve(host, srv)
            except Exception:
                ips = []
            if ips:
                break
        if not ips and c:
            ips = c[1]
        if not ips:
            if box and isinstance(box[0], Exception):
                raise box[0]
            raise socket.gaierror(-2, "dns timeout")
        _cache[host] = (now, ips)
    st = type or socket.SOCK_STREAM
    return [(socket.AF_INET, st, 6 if st == socket.SOCK_STREAM else 17, "", (ip, port or 0)) for ip in ips]


def install():
    socket.getaddrinfo = _gai


def _default_route():
    try:
        with open("/proc/net/route") as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) > 3 and p[1] == "00000000" and int(p[3], 16) & 2:
                    return p[0]
    except Exception:
        pass
    return None


def status():
    """-> (stage, text): nolink / noip / nodns / noconn / ok"""
    if _default_route() is None:
        wl = [n for n in (os.listdir("/sys/class/net") if os.path.isdir("/sys/class/net") else []) if n.startswith(("wlan", "wl"))]
        if not wl:
            return "nolink", "Chưa thấy WiFi - hãy bật WiFi trong cài đặt máy"
        return "noip", "Đang kết nối WiFi / chờ nhận địa chỉ IP..."
    try:
        ip = _gai(TEST_HOST, 443)[0][4][0]
    except Exception:
        return "nodns", "WiFi đã nối, đang chờ DNS..."
    try:
        s = socket.create_connection((ip, 443), timeout=4)
        s.close()
    except Exception:
        return "noconn", "Đang chờ kết nối ra Internet..."
    return "ok", "Đã kết nối mạng"


def kick_wifi():
    """one gentle nudge: ask wpa_supplicant to reconnect (no-op if wpa_cli is missing)"""
    try:
        if shutil.which("wpa_cli"):
            subprocess.run(["wpa_cli", "-i", "wlan0", "reconnect"], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=3)
    except Exception:
        pass
