# -*- coding: utf-8 -*-
"""pad.py - Linux joystick (/dev/input/js*) reader with auto-repeat -> logical button names.
Logical names: a b x y l1 r1 l2 r2 select start menu l3 r3 up down left right rup rdown rleft rright
TrimUI: bottom=B(0) right=A(1) left=Y(2) top=X(3)."""
import os, glob, time, struct

BTN = {0: "b", 1: "a", 2: "y", 3: "x", 4: "l1", 5: "r1", 6: "select", 7: "start", 8: "menu",
       9: "l3", 10: "r3", 11: "up", 12: "down", 13: "left", 14: "right"}
AXIS = {0: "lx", 1: "ly", 2: "l2", 3: "rx", 4: "ry", 5: "r2", 6: "hatx", 7: "haty", 16: "hatx", 17: "haty"}
REPEATING = ("up", "down", "left", "right", "rup", "rdown", "rleft", "rright")
HERE = os.path.dirname(os.path.abspath(__file__))
LOGICAL = {"bottom": "b", "right": "a", "left": "y", "top": "x"}


def _load_map():
    p = os.path.join(HERE, "padmap.txt")     # optional: "btn 0 = b"  /  "axis 2 = l2"
    if not os.path.exists(p):
        return
    for line in open(p, encoding="utf-8", errors="ignore"):
        line = line.split("#")[0].strip()
        if "=" not in line:
            continue
        a, b = [x.strip() for x in line.split("=", 1)]
        try:
            kind, num = a.split()
            (BTN if kind == "btn" else AXIS)[int(num)] = LOGICAL.get(b, b)
        except Exception:
            pass


class Pad:
    def __init__(self):
        _load_map()
        self.fd = None
        self.dev = None
        self.buf = b""
        self.state = {}      # axis-derived direction -> -1/0/1
        self.rep = {}        # name -> next repeat time
        self.last_open = 0

    def open(self):
        if self.fd is not None or time.time() - self.last_open < 1.0:
            return
        self.last_open = time.time()
        devs = [os.environ["PAD_DEV"]] if os.environ.get("PAD_DEV") else sorted(glob.glob("/dev/input/js*"))
        for d in devs:
            try:
                self.fd = os.open(d, os.O_RDONLY | os.O_NONBLOCK); self.dev = d; self.evdev = None; return
            except Exception:
                pass
        if not os.environ.get("PAD_DEV"):
            self._open_evdev()          # firmwares without joydev (e.g. KNULLI): read /dev/input/event* directly

    def fileno(self):
        return self.fd if self.fd is not None else -1

    # ---- evdev fallback: translate input_event -> joystick-style packets so the rest is shared ----
    evdev = None

    def _open_evdev(self):
        import fcntl
        def bits(fd, ev, n):
            buf = bytearray(n)
            fcntl.ioctl(fd, (2 << 30) | (n << 16) | (0x45 << 8) | (0x20 + ev), buf)
            return [i for i in range(n * 8) if buf[i // 8] >> (i % 8) & 1]
        for d in sorted(glob.glob("/dev/input/event*")):
            try:
                fd = os.open(d, os.O_RDONLY | os.O_NONBLOCK)
            except Exception:
                continue
            try:
                keys = bits(fd, 1, 96)
                if 304 not in keys or 305 not in keys:          # BTN_SOUTH / BTN_EAST = gamepad
                    os.close(fd); continue
                order = sorted(c for c in keys if c >= 0x100) + sorted(c for c in keys if c < 0x100)   # joydev order
                kmap = {c: i for i, c in enumerate(order)}
                absc = sorted(bits(fd, 3, 8)) if True else []
                amap, ainfo = {}, {}
                for i, c in enumerate(absc):
                    buf = bytearray(24)
                    fcntl.ioctl(fd, (2 << 30) | (24 << 16) | (0x45 << 8) | (0x40 + c), buf)
                    _, mn, mx = struct.unpack("iii", bytes(buf[:12]))
                    amap[c] = i; ainfo[c] = (mn, mx)
                self.fd, self.dev, self.evdev = fd, d, (kmap, amap, ainfo)
                return
            except Exception:
                try: os.close(fd)
                except Exception: pass

    def _evdev_to_js(self, chunk):
        kmap, amap, ainfo = self.evdev
        sz = struct.calcsize("llHHi")
        self.ebuf = getattr(self, "ebuf", b"") + chunk
        out = b""
        while len(self.ebuf) >= sz:
            _, _, typ, code, val = struct.unpack("llHHi", self.ebuf[:sz]); self.ebuf = self.ebuf[sz:]
            if typ == 1 and code in kmap and val in (0, 1):
                out += struct.pack("IhBB", 0, val, 1, kmap[code])
            elif typ == 3 and code in amap:
                mn, mx = ainfo[code]
                if mx > mn:
                    v = int((val - mn) * 65534 / (mx - mn)) - 32767
                    out += struct.pack("IhBB", 0, max(-32767, min(32767, v)), 2, amap[code])
        return out

    def _dir(self, name, v):
        th = 16000
        if name in ("l2", "r2"):
            return {name: 1 if v > th else 0}
        d = -1 if v < -th else 1 if v > th else 0
        return {"lx": {"x": d}, "hatx": {"x": d}, "ly": {"y": d}, "haty": {"y": d},
                "rx": {"rx": d}, "ry": {"ry": d}}.get(name, {})

    def read(self):
        """-> list of (name, 'down'|'up')"""
        self.open()
        ev = []
        if self.fd is None:
            return ev
        try:
            chunk = os.read(self.fd, 8 * 64)
        except BlockingIOError:
            chunk = b""
        except OSError:
            try: os.close(self.fd)
            except Exception: pass
            self.fd = None; return ev
        if self.evdev and chunk:
            chunk = self._evdev_to_js(chunk)
        self.buf += chunk
        while len(self.buf) >= 8:
            _, value, typ, num = struct.unpack("IhBB", self.buf[:8])
            self.buf = self.buf[8:]
            if typ & 0x80:          # JS_EVENT_INIT: initial state dump, not a real press
                continue
            if typ == 1:
                n = BTN.get(num)
                if n:
                    self._emit(ev, n, bool(value))
            elif typ == 2:
                n = AXIS.get(num)
                if not n:
                    continue
                for k, d in self._dir(n, value).items():
                    old = self.state.get(k, 0)
                    if d == old:
                        continue
                    self.state[k] = d
                    if k in ("l2", "r2"):
                        self._emit(ev, k, bool(d)); continue
                    names = {"x": ("left", "right"), "y": ("up", "down"), "rx": ("rleft", "rright"),
                             "ry": ("rup", "rdown")}[k]
                    for nm in names:       # release whichever side was active
                        if nm in self.rep or (old != 0 and nm == names[0 if old < 0 else 1]):
                            self._emit(ev, nm, False)
                    if d:
                        self._emit(ev, names[0 if d < 0 else 1], True)
        return ev

    def _emit(self, ev, name, down):
        if name in REPEATING:
            if down:
                self.rep[name] = time.time() + 0.42
            else:
                if name not in self.rep:
                    return
                self.rep.pop(name, None)
        ev.append((name, "down" if down else "up"))

    def repeats(self):
        now, out = time.time(), []
        for n, t in list(self.rep.items()):
            if now >= t:
                self.rep[n] = now + 0.09
                out.append((n, "rep"))
        return out
