#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Local HTTP -> HTTPS relay for mpv.

Many handheld mpv builds have no TLS support, or TikTok/tikwm CDNs reject
requests without browser headers ("loading failed"). This relay lets mpv open
plain http://127.0.0.1:PORT/p/x.mp4?u=<encoded https url>; Python fetches the
real URL with proper headers and streams it back (Range requests supported).
"""
import netfix; netfix.install()
import os, sys, ssl, socket, time, hashlib, threading, urllib.request, urllib.parse
from http.server import BaseHTTPRequestHandler
from socketserver import ThreadingMixIn, TCPServer

UA = ('Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36')
try:
    CTX = ssl._create_unverified_context()
except AttributeError:
    CTX = None


# ---- cache + prefetch (idea borrowed from ROMCloud: stage as .partial, verify, then promote) ----
M3U = os.environ.get("TIKTOK_M3U", "/tmp/tiktok.m3u")
CACHE = os.environ.get("TIKTOK_CACHE", "/tmp/tiktok_cache")
CACHE_MAX = int(os.environ.get("TIKTOK_CACHE_MB", "160")) * 1024 * 1024
AHEAD = 6                      # how many upcoming videos to fetch in advance
last_id = [None]
lock = threading.Lock()
os.makedirs(CACHE, exist_ok=True)


def referer_for(url):
    return "https://www.tikwm.com/" if "tikwm" in url else "https://www.tiktok.com/"


def key_of(target):
    return hashlib.sha1(target.encode()).hexdigest()[:20]


def cpath(target):
    return os.path.join(CACHE, key_of(target) + ".mp4")


def playlist():
    """[(video_id, target_url)] in playlist order."""
    out = []
    try:
        for line in open(M3U, encoding="utf-8", errors="ignore"):
            line = line.strip()
            if line.startswith("http://127.0.0.1") and "u=" in line:
                q = urllib.parse.parse_qs(urllib.parse.urlparse(line).query)
                vid = (q.get("tiktok_id") or [""])[0]
                out.append((vid, (q.get("u") or [""])[0]))
    except Exception:
        pass
    return out


def download(target):
    """Fetch whole video to <key>.partial, then rename atomically."""
    final = cpath(target)
    part = final + ".partial"
    if os.path.exists(final):
        return True
    try:
        req = urllib.request.Request(target, headers={
            "User-Agent": UA, "Accept": "*/*", "Referer": referer_for(target)})
        r = urllib.request.urlopen(req, timeout=30, context=CTX)
        want = int(r.headers.get("Content-Length") or 0)
        got = 0
        with open(part, "wb") as f:
            while True:
                c = r.read(131072)
                if not c:
                    break
                f.write(c); got += len(c)
        if got < 1024 or (want and got != want):
            raise IOError("incomplete %d/%d" % (got, want))
        os.replace(part, final)
        return True
    except Exception:
        try: os.remove(part)
        except Exception: pass
        return False


def evict(keep):
    """LRU cleanup: stay under CACHE_MAX, never remove files in `keep`."""
    try:
        files = []
        for n in os.listdir(CACHE):
            p = os.path.join(CACHE, n)
            if n.endswith(".partial"):
                if time.time() - os.path.getmtime(p) > 300:
                    os.remove(p)
                continue
            files.append((os.path.getmtime(p), p, os.path.getsize(p)))
        total = sum(x[2] for x in files)
        for _, p, sz in sorted(files):
            if total <= CACHE_MAX:
                break
            if p in keep:
                continue
            os.remove(p); total -= sz
    except Exception:
        pass


def prefetch_loop():
    """keep the next AHEAD videos cached; two downloads run in parallel so fast scrolling never waits"""
    failed, busy, blk = {}, set(), threading.Lock()

    def job(t):
        ok = download(t)
        with blk:
            busy.discard(t)
            if not ok:
                failed[t] = failed.get(t, 0) + 1

    while True:
        time.sleep(0.25)
        try:
            pl = playlist()
            if not pl:
                continue
            ids = [v for v, _ in pl]
            cur = ids.index(last_id[0]) if last_id[0] in ids else -1
            wanted = pl[cur + 1: cur + 1 + AHEAD] if cur >= 0 else pl[:AHEAD]
            keep = {cpath(t) for _, t in wanted}
            if cur >= 0:
                keep.add(cpath(pl[cur][1]))
            evict(keep)
            for vid, t in wanted:
                if os.path.exists(cpath(t)) or failed.get(t, 0) > 2:
                    continue
                with blk:
                    if t in busy:
                        continue
                    if len(busy) >= 2:
                        break
                    busy.add(t)
                threading.Thread(target=job, args=(t,), daemon=True).start()
        except Exception:
            pass


def parse_range(h, size):
    try:
        a, b = h.replace("bytes=", "").split("-", 1)
        if a == "":
            n = int(b); return max(size - n, 0), size - 1
        start = int(a); end = int(b) if b else size - 1
        return start, min(end, size - 1)
    except Exception:
        return None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _go(self, head_only):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        target = (q.get("u") or [""])[0]
        if not target.startswith("http"):
            self.send_error(400)
            return
        vid = (q.get("tiktok_id") or [""])[0]
        if vid:
            last_id[0] = vid
        cp = cpath(target)
        if os.path.exists(cp):
            if self._serve_file(cp, head_only):
                return
        hdr = {"User-Agent": UA, "Accept": "*/*",
               "Referer": referer_for(target), "Connection": "close"}
        if self.headers.get("Range"):
            hdr["Range"] = self.headers["Range"]
        try:
            req = urllib.request.Request(target, headers=hdr)
            r = urllib.request.urlopen(req, timeout=30, context=CTX)
        except urllib.error.HTTPError as e:
            if e.code == 416:
                self.send_response(416); self.send_header("Content-Length", "0")
                self.end_headers(); return
            self.send_error(502, "upstream %s" % e.code); return
        except Exception as e:
            self.send_error(502, str(e)[:80]); return
        try:
            self.send_response(r.status)
            ctype = r.headers.get("Content-Type", "video/mp4")
            if "text" in ctype or "json" in ctype:
                ctype = "video/mp4"
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            for k in ("Content-Length", "Content-Range"):
                if r.headers.get(k):
                    self.send_header(k, r.headers[k])
            self.send_header("Connection", "close")
            self.end_headers()
            if head_only:
                return
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            pass
        finally:
            try: r.close()
            except Exception: pass

    def _serve_file(self, path, head_only):
        try:
            size = os.path.getsize(path)
            rng = parse_range(self.headers["Range"], size) if self.headers.get("Range") else None
            if rng and rng[0] > rng[1]:
                self.send_response(416); self.send_header("Content-Length", "0")
                self.end_headers(); return True
            start, end = rng if rng else (0, size - 1)
            self.send_response(206 if rng else 200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            if rng:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.send_header("Connection", "close")
            self.end_headers()
            if head_only:
                return True
            with open(path, "rb") as f:
                f.seek(start); left = end - start + 1
                while left > 0:
                    c = f.read(min(65536, left))
                    if not c:
                        break
                    self.wfile.write(c); left -= len(c)
            os.utime(path, None)
            return True
        except (BrokenPipeError, ConnectionResetError, socket.timeout):
            return True
        except Exception:
            return False

    def do_GET(self):
        self._go(False)

    def do_HEAD(self):
        self._go(True)


class Server(ThreadingMixIn, TCPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8808
    threading.Thread(target=prefetch_loop, daemon=True).start()
    Server(("127.0.0.1", port), Handler).serve_forever()
