# -*- coding: utf-8 -*-
"""screens.py - menu screens drawn with gfx (settings, lists, search keyboard, comments)."""
import time, math
import gfx, telex
from gfx import fmt_num


# ============================================================ helpers
def badge(cv, th, x, y, label, size):
    """small rounded button hint like [A]"""
    w = max(size, cv.measure(label, int(size * 0.62), True)[0] + int(size * 0.5))
    cv.rect(x, y, w, size, th.LINE if not th.light else th.c((190, 190, 205)), radius=size // 3)
    cv.text(x + w // 2, y + int(size * 0.14), label, int(size * 0.62), th.FG, bold=True, anchor="c")
    return w


def hints(cv, th, x, y, size, pairs):
    for lab, txt in pairs:
        x += badge(cv, th, x, y, lab, size) + int(size * 0.25)
        x += cv.text(x, y + int(size * 0.12), txt, int(size * 0.62), th.SUB) + int(size * 0.7)
    return x


class Screen:
    pause = False        # pause the video while this screen is open
    backdrop = True      # dim the video behind it
    dock = "center"

    def rect(self, app):
        W, H = app.W, app.H
        if self.dock == "right":
            w = min(app.px(self.width or 470), W - 40)
            return W - w - app.px(14), app.px(14), w, H - app.px(28)
        w = min(app.px(self.width or 640), W - 30)
        h = min(app.px(self.height or 600), H - 24)
        return (W - w) // 2, (H - h) // 2, w, h

    width = None
    height = None

    def draw(self, app, cv, w, h): pass
    def key(self, app, name, rep): pass
    def tick(self, app): return False
    def on_open(self, app): pass
    def on_close(self, app): pass


# ============================================================ items + list screen
class Item:
    def __init__(self, label, kind="action", act=None, get=None, set=None, opts=None, lo=0, hi=0, step=1,
                 fmt=None, sub="", default=None, icon=None):
        self.label, self.kind, self.act, self.get, self.set = label, kind, act, get, set
        self.opts, self.lo, self.hi, self.step, self.fmt = opts, lo, hi, step, fmt
        self.sub, self.default, self.icon = sub, default, icon

    @property
    def selectable(self): return self.kind not in ("header", "info")

    def value(self):
        if self.get is None:
            return None
        v = self.get()
        if self.kind == "choice":
            for ov, ol in self.opts:
                if ov == v:
                    return ol
            return str(v)
        if self.kind == "toggle":
            return "Bật" if v else "Tắt"
        if self.kind == "slider":
            return self.fmt(v) if self.fmt else str(v)
        return str(v)

    def adjust(self, d):
        if self.kind == "choice" and self.opts:
            vals = [o[0] for o in self.opts]
            cur = self.get()
            i = vals.index(cur) if cur in vals else 0
            self.set(vals[(i + d) % len(vals)])
        elif self.kind == "toggle":
            self.set(not self.get())
        elif self.kind == "slider":
            v = max(self.lo, min(self.hi, self.get() + d * self.step))
            self.set(v)

    def activate(self):
        if self.kind in ("choice", "toggle"):
            self.adjust(1)
        elif self.kind == "slider":
            if self.default is not None:
                self.set(self.default)
        elif self.kind == "action" and self.act:
            self.act()


class ListScreen(Screen):
    def __init__(self, title, items, dock="center", pause=True, width=None, height=None, header=None,
                 header_h=0, footer=None, on_back=None, backdrop=True, on_change=None):
        self.title, self.items, self.dock, self.pause = title, items, dock, pause
        self.width, self.height, self.backdrop = width, height, backdrop
        self.header, self.header_h = header, header_h        # header(app, cv, x, y, w) draws custom block
        self.footer = footer
        self.on_back = on_back
        self.on_change = on_change
        self.cursor = next((i for i, it in enumerate(items) if it.selectable), 0)
        self.top = 0

    # -- navigation
    def _move(self, d):
        n = len(self.items)
        if not n: return
        c = self.cursor
        for _ in range(n):
            c = (c + d) % n
            if self.items[c].selectable:
                self.cursor = c; return

    def key(self, app, name, rep):
        it = self.items[self.cursor] if self.items else None
        if name == "up": self._move(-1)
        elif name == "down": self._move(1)
        elif name in ("l2", "r2"):
            for _ in range(6): self._move(-1 if name == "l2" else 1)
        elif name in ("left", "right") and it and it.kind in ("choice", "toggle", "slider"):
            it.adjust(-1 if name == "left" else 1)
            if self.on_change: self.on_change(app)
        elif name == "a" and it and not rep:
            it.activate()
            if self.on_change and it.kind in ("choice", "toggle", "slider"): self.on_change(app)
        elif name in ("b", "y", "menu") and not rep:
            (self.on_back or app.close_screen)()
        app.redraw_screen()

    def on_close(self, app): pass

    # -- drawing
    def draw(self, app, cv, w, h):
        th, px, fs = app.th, app.px, app.fs
        cv.clear((0, 0, 0, 0))
        cv.rect(0, 0, w, h, th.PS if self.dock == "right" else th.P, radius=px(18))
        pad = px(22)
        y = px(16)
        cv.text(pad, y, self.title, fs(26), th.FG, bold=True)
        cv.rect(pad, y + fs(26) + px(8), px(54), px(4), th.A, radius=px(2))
        y += fs(26) + px(22)
        if self.header:
            self.header(app, cv, pad, y, w - 2 * pad)
            y += self.header_h
        foot_h = px(34)
        rh = px(44)
        avail = h - y - foot_h - px(8)
        vis = max(1, avail // rh)
        if self.cursor < self.top: self.top = self.cursor
        if self.cursor >= self.top + vis: self.top = self.cursor - vis + 1
        self.top = max(0, min(self.top, max(0, len(self.items) - vis)))
        for i in range(self.top, min(len(self.items), self.top + vis)):
            it = self.items[i]
            ry = y + (i - self.top) * rh
            sel = (i == self.cursor) and it.selectable
            if sel:
                cv.rect(pad - px(8), ry, w - 2 * pad + px(16), rh - px(4), th.A, radius=px(10))
            fg = th.on_acc() if sel else th.FG
            sub = th.on_acc() if sel else th.SUB
            if it.kind == "header":
                cv.text(pad, ry + px(12), it.label.upper(), fs(14), th.A, bold=True)
                continue
            if it.kind == "info":
                cv.text(pad, ry + px(8), it.label, fs(17), th.SUB)
                continue
            tx = pad
            if it.icon:
                cv.icon(it.icon, pad, ry + px(7), px(28), fg)
                tx += px(40)
            maxlab = (w - 2 * pad) - (px(230) if it.get else px(60))
            cv.text(tx, ry + px(8), cv.fit(it.label, fs(20), maxlab), fs(20), fg)
            if it.sub and not it.get:
                cv.text(w - pad, ry + px(11), cv.fit(it.sub, fs(16), px(220)), fs(16), sub, anchor="r")
            val = it.value() if it.get else None
            if val is not None:
                if it.kind == "slider":
                    bw = px(110)
                    bx = w - pad - bw - px(88)
                    span = max(1, it.hi - it.lo)
                    cv.rect(bx, ry + px(19), bw, px(6), (0, 0, 0, 90) if sel else th.LINE, radius=px(3))
                    cv.rect(bx, ry + px(19), int(bw * (it.get() - it.lo) / span), px(6), fg, radius=px(3))
                    cv.text(w - pad, ry + px(8), val, fs(18), fg, anchor="r")
                else:
                    txt = ("<  " + val + "  >") if (sel and it.kind != "toggle") else val
                    col = fg if sel else (th.A if it.kind == "toggle" and it.get() else th.SUB)
                    cv.text(w - pad, ry + px(8), cv.fit(txt, fs(19), px(240)), fs(19), col, anchor="r", bold=(it.kind == "toggle"))
        if len(self.items) > vis:
            sh = max(px(20), int(avail * vis / len(self.items)))
            sy = y + int((avail - sh) * self.top / max(1, len(self.items) - vis))
            cv.rect(w - px(8), sy, px(4), sh, th.LINE, radius=px(2))
        fy = h - foot_h
        cv.rect(pad, fy - px(4), w - 2 * pad, 1, th.LINE)
        hs = self.footer or [("A", "Chọn"), ("B", "Quay lại"), ("<>", "Đổi")]
        hints(cv, th, pad, fy + px(4), px(24), hs)


# ============================================================ search keyboard
ROWS = ["1234567890", "qwertyuiop", "asdfghjkl.", "zxcvbnm@#_"]
SPECIAL = [("Telex", 0, 2), ("Dấu cách", 2, 4), ("Xóa", 6, 2), ("Tìm", 8, 2)]


class SearchScreen(Screen):
    pause = True
    width = 800
    height = 600
    TITLE = "Tìm kiếm"
    HINT = "Nhập từ khóa, @tác giả hoặc #hashtag"
    EMPTY_MSG = "Hãy nhập từ khóa"
    MAXLEN = 60
    rows = ROWS
    special = SPECIAL
    HINTS = [("A", "Gõ"), ("Y", "Xóa"), ("X", "Cách"), ("Start", "Tìm"), ("R1", "Telex"), ("B", "Đóng")]

    def __init__(self, chips, on_submit):
        self.raw = ""
        self.telex_on = True
        self.row, self.col = 1, 0           # row -1 = suggestion chips
        self.chip = 0
        self.chips = chips                  # [(label, query)]
        self.on_submit = on_submit
        self.t0 = time.time()
        self.blink = True

    def text(self):
        return telex.compose(self.raw) if self.telex_on else self.raw

    def tick(self, app):
        b = int((time.time() - self.t0) * 2) % 2 == 0
        if b != self.blink:
            self.blink = b; return True
        return False

    def _type(self, ch):
        if len(self.raw) < self.MAXLEN:
            self.raw += ch

    def _submit(self, app):
        q = self.text().strip()
        if not q:
            app.toast(self.EMPTY_MSG); return
        self.on_submit(q)

    def _press(self, app):
        if self.row == -1:
            if self.chips:
                self.on_submit(self.chips[self.chip][1])
            return
        if self.row == len(self.rows):
            for name, c0, span in self.special:
                if c0 <= self.col < c0 + span:
                    if name == "Telex": self.telex_on = not self.telex_on; app.toast("Gõ Telex: " + ("Bật" if self.telex_on else "Tắt"))
                    elif name == "Dấu cách": self._type(" ")
                    elif name == "Xóa": self.raw = self.raw[:-1]
                    else: self._submit(app)
            return
        self._type(self.rows[self.row][self.col])

    def key(self, app, name, rep):
        nrows = len(self.rows) + 1
        if name == "up":
            self.row = self.row - 1 if self.row > -1 else nrows - 1
            if self.row == -1 and not self.chips: self.row = nrows - 1
        elif name == "down":
            self.row = self.row + 1 if self.row < nrows - 1 else (-1 if self.chips else 0)
        elif name == "left":
            if self.row == -1 and self.chips: self.chip = (self.chip - 1) % len(self.chips)
            elif self.row == len(self.rows):
                i = next((i for i, s in enumerate(self.special) if s[1] <= self.col < s[1] + s[2]), 0)
                self.col = self.special[(i - 1) % len(self.special)][1]
            else: self.col = (self.col - 1) % 10
        elif name == "right":
            if self.row == -1 and self.chips: self.chip = (self.chip + 1) % len(self.chips)
            elif self.row == len(self.rows):
                i = next((i for i, s in enumerate(self.special) if s[1] <= self.col < s[1] + s[2]), 0)
                self.col = self.special[(i + 1) % len(self.special)][1]
            else: self.col = (self.col + 1) % 10
        elif name == "a" and not rep: self._press(app)
        elif name == "y": self.raw = self.raw[:-1]
        elif name == "x" and not rep: self._type(" ")
        elif name == "start" and not rep: self._submit(app)
        elif name == "r1" and not rep: self.telex_on = not self.telex_on
        elif name in ("b", "menu") and not rep: app.close_screen(); return
        app.redraw_screen()

    def draw(self, app, cv, w, h):
        th, px, fs = app.th, app.px, app.fs
        cv.clear((0, 0, 0, 0))
        cv.rect(0, 0, w, h, th.P, radius=px(18))
        pad = px(24)
        cv.text(pad, px(14), self.TITLE, fs(26), th.FG, bold=True)
        cv.rect(pad, px(14) + fs(26) + px(8), px(54), px(4), th.A, radius=px(2))
        y = px(14) + fs(26) + px(24)
        # query box
        qh = px(56)
        cv.rect(pad, y, w - 2 * pad, qh, th.LINE, radius=px(14))
        cv.icon("search", pad + px(12), y + px(12), px(32), th.SUB)
        t = self.text()
        shown = cv.fit(t[-80:], fs(26), w - 2 * pad - px(190)) if t else ""
        if not t:
            cv.text(pad + px(56), y + px(12), self.HINT, fs(20), th.SUB)
        else:
            tw = cv.text(pad + px(56), y + px(11), shown, fs(26), th.FG)
            if self.blink:
                cv.rect(pad + px(58) + tw, y + px(12), px(2), px(32), th.A)
        cv.text(w - pad - px(14), y + px(18), "Telex " + ("BẬT" if self.telex_on else "TẮT"), fs(15),
                th.A if self.telex_on else th.SUB, bold=True, anchor="r")
        y += qh + px(12)
        # suggestion chips
        ch = px(38)
        if self.chips:
            x = pad
            start = max(0, self.chip - 2) if self.row == -1 else 0
            for i in range(start, len(self.chips)):
                lab = self.chips[i][0]
                cw = cv.measure(lab, fs(16))[0] + px(26)
                if x + cw > w - pad:
                    break
                sel = (self.row == -1 and i == self.chip)
                cv.rect(x, y, cw, ch, th.A if sel else th.LINE, radius=ch // 2)
                cv.text(x + cw // 2, y + px(8), lab, fs(16), th.on_acc() if sel else th.FG, anchor="c")
                x += cw + px(8)
        y += ch + px(12)
        # keyboard
        kw = (w - 2 * pad) // 10
        kh = px(54)
        for r, row in enumerate(self.rows):
            for c, chx in enumerate(row):
                sel = (self.row == r and self.col == c)
                x = pad + c * kw
                cv.rect(x + px(3), y + px(3), kw - px(6), kh - px(6), th.A if sel else th.LINE, radius=px(10))
                cv.text(x + kw // 2, y + px(11), chx, fs(26), th.on_acc() if sel else th.FG, anchor="c", bold=sel)
            y += kh
        for name, c0, span in self.special:
            sel = (self.row == len(self.rows) and c0 <= self.col < c0 + span)
            x = pad + c0 * kw
            label = name if name != "Telex" else ("Telex: Bật" if self.telex_on else "Telex: Tắt")
            fill = th.A if sel else (th.A2 if name == "Tìm" and False else th.LINE)
            cv.rect(x + px(3), y + px(3), span * kw - px(6), kh - px(6), fill, radius=px(10))
            cv.text(x + span * kw // 2, y + px(13), label, fs(20), th.on_acc() if sel else th.FG, anchor="c", bold=True)
        fy = h - px(38)
        cv.rect(pad, fy - px(4), w - 2 * pad, 1, th.LINE)
        hints(cv, th, pad, fy + px(4), px(24), self.HINTS)



COMMENT_ROWS = ["1234567890", "qwertyuiop", "asdfghjkl,", "zxcvbnm.!?"]
COMMENT_SPECIAL = [("Telex", 0, 2), ("Dấu cách", 2, 4), ("Xóa", 6, 2), ("Gửi", 8, 2)]


class ComposeScreen(SearchScreen):
    """keyboard for writing a comment (same Telex keyboard as search)"""
    TITLE = "Viết bình luận"
    HINT = "Gõ bình luận của bạn..."
    EMPTY_MSG = "Hãy nhập bình luận"
    MAXLEN = 200
    rows = COMMENT_ROWS
    special = COMMENT_SPECIAL
    HINTS = [("A", "Gõ"), ("Y", "Xóa"), ("X", "Cách"), ("Start", "Gửi"), ("R1", "Telex"), ("B", "Đóng")]

    def __init__(self, on_submit):
        SearchScreen.__init__(self, [], on_submit)


# ============================================================ comments
class CommentsScreen(Screen):
    dock = "right"
    pause = False
    backdrop = False
    width = 500

    def __init__(self, video, loader, on_write=None, on_delete=None):
        self.video = video
        self.on_write = on_write
        self.on_delete = on_delete
        self.items = []
        self.cursor = 0
        self.top = 0
        self.state = "loading"      # loading | ok | error
        self.more = False
        self.next = 0
        self.loader = loader        # loader(screen, cursor)
        self.busy = False

    def on_open(self, app):
        self.loader(self, 0)

    def got(self, app, res, append=False):
        self.busy = False
        if res is None:
            if not self.items: self.state = "error"
        else:
            items, nxt, more = res
            self.items = (self.items + items) if append else items
            self.next, self.more = nxt, more
            self.state = "ok"
        app.redraw_screen()

    def add_local(self, app, c):
        self.items.insert(0, c)
        self.cursor = 0; self.top = 0; self.state = "ok"
        app.redraw_screen()

    def key(self, app, name, rep):
        n = len(self.items)
        if name in ("x", "start") and not rep and self.on_write:
            self.on_write(self); return
        if name == "r1" and not rep and self.on_delete and n and self.items[self.cursor].get("mine"):
            c = self.items.pop(self.cursor)
            self.cursor = max(0, min(self.cursor, len(self.items) - 1))
            self.on_delete(c); app.redraw_screen(); return
        if name == "up": self.cursor = max(0, self.cursor - 1)
        elif name == "down": self.cursor = min(max(0, n - 1), self.cursor + 1)
        elif name == "l2": self.cursor = max(0, self.cursor - 4)
        elif name == "r2": self.cursor = min(max(0, n - 1), self.cursor + 4)
        elif name in ("b", "l1", "y", "menu") and not rep:
            app.close_screen(); return
        if self.more and not self.busy and self.cursor >= n - 3 and n:
            self.busy = True; self.loader(self, self.next)
        app.redraw_screen()

    def draw(self, app, cv, w, h):
        th, px, fs = app.th, app.px, app.fs
        cv.clear((0, 0, 0, 0))
        cv.rect(0, 0, w, h, th.PS, radius=px(18))
        pad = px(20)
        cv.text(pad, px(14), "Bình luận", fs(26), th.FG, bold=True)
        cnt = fmt_num(self.video.get("comments", 0)) if self.video.get("comments") else ""
        if cnt:
            cv.text(w - pad, px(20), cnt, fs(18), th.SUB, anchor="r")
        cv.rect(pad, px(14) + fs(26) + px(8), px(54), px(4), th.A, radius=px(2))
        y0 = px(14) + fs(26) + px(24)
        yb = h - px(40)
        if self.state == "loading":
            cv.text(w // 2, h // 2 - px(10), "Đang tải bình luận...", fs(20), th.SUB, anchor="c")
        elif self.state == "error" or not self.items:
            msg = "Không tải được bình luận" if self.state == "error" else "Chưa có bình luận - nhấn X để viết"
            cv.text(w // 2, h // 2 - px(10), msg, fs(20), th.SUB, anchor="c")
        else:
            # keep cursor visible: walk back from cursor until it fits
            def hgt(c):
                lines = cv.wrap(c["text"] or "(không có nội dung)", fs(18), w - 2 * pad - px(20), 5)
                return px(34) + len(lines) * fs(18) * 1.25 + px(14), lines
            top = min(self.top, self.cursor)
            while True:
                tot, ok = 0, False
                for i in range(top, self.cursor + 1):
                    tot += hgt(self.items[i])[0]
                if tot <= yb - y0 or top >= self.cursor:
                    break
                top += 1
            self.top = top
            y = y0
            for i in range(self.top, len(self.items)):
                c = self.items[i]
                ch, lines = hgt(c)
                if y + ch > yb and i != self.top:
                    break
                sel = i == self.cursor
                if sel:
                    cv.rect(pad - px(6), int(y), w - 2 * pad + px(12), int(ch - px(4)), th.LINE, radius=px(10))
                cv.text(pad, int(y) + px(6), cv.fit(c["user"], fs(16), w - 2 * pad - px(110)), fs(16), th.A, bold=True)
                cv.icon("heart", w - pad - px(78), int(y) + px(7), px(16), th.SUB)
                cv.text(w - pad - px(56), int(y) + px(6), fmt_num(c["likes"]), fs(15), th.SUB)
                ty = y + px(32)
                for ln in lines:
                    cv.text(pad, int(ty), ln, fs(18), th.FG)
                    ty += fs(18) * 1.25
                y += ch
        fy = h - px(36)
        cv.rect(pad, fy - px(4), w - 2 * pad, 1, th.LINE)
        hints(cv, th, pad, fy + px(2), px(24), [("^v", "Cuộn"), ("X", "Viết"), ("R1", "Xóa của bạn"), ("B", "Đóng")])
