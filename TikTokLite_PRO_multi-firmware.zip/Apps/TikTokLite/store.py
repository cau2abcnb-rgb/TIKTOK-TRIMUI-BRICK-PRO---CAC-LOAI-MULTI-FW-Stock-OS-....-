# -*- coding: utf-8 -*-
"""store.py - settings + favourites / following / history, saved as JSON next to the app."""
import os, json, time, threading

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
os.makedirs(DATA, exist_ok=True)
_lock = threading.Lock()

DEFAULTS = {
    # video / audio
    "rotate": 0, "zoom": 0, "brightness": 0, "contrast": 0, "saturation": 0, "gamma": 0,
    "speed": 100, "volume": 80, "mute": False, "quality": "sd", "perf": "balanced",
    "autoscroll": False, "autoscroll_secs": 0,
    # theme
    "accent": "tiktok", "mode": "dark", "panel_alpha": 80, "font_scale": 100,
    "hud": "side", "hud_hide": 0, "show_progress": True, "show_stats": True, "intro": True,
    # feed
    "region": "vietnam", "topics": ["thinhhanh"], "shuffle": False, "skip_watched": False,
    "search_history": [],
}


def _path(n):
    return os.path.join(DATA, n)


def load(name, default):
    try:
        with open(_path(name), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save(name, obj):
    with _lock:
        try:
            tmp = _path(name) + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, indent=1)
            os.replace(tmp, _path(name))
        except Exception:
            pass


class Settings(dict):
    def __init__(self):
        super().__init__(DEFAULTS)
        d = load("settings.json", None)
        if d is None:                      # migrate the old app_settings.json
            old = os.path.join(HERE, "app_settings.json")
            try:
                with open(old, encoding="utf-8") as f:
                    o = json.load(f)
                d = {"topics": o.get("topics") or ["thinhhanh"], "shuffle": o.get("shuffle", False),
                     "skip_watched": o.get("skip_watched", False), "autoscroll": o.get("autoscroll", False),
                     "region": o.get("filter_region", "vietnam"), "search_history": o.get("search_history", [])}
            except Exception:
                d = {}
        for k, v in d.items():
            if k in DEFAULTS:
                self[k] = v

    def commit(self):
        save("settings.json", dict(self))


class Library:
    """favourites (liked), following (creators), history (watched)."""
    def __init__(self):
        self.liked = load("liked.json", [])
        self.following = load("following.json", [])
        self.history = load("history.json", [])
        self.my_comments = load("comments.json", {})     # {video_id: [comment, ...]} written on this device
        self.liked_ids = {str(v.get("id")) for v in self.liked}
        self.seen_ids = {str(v.get("id")) for v in self.history}
        try:   # migrate old watched_ids.txt
            for line in open(os.path.join(HERE, "watched_ids.txt")):
                if line.strip():
                    self.seen_ids.add(line.strip())
        except Exception:
            pass

    @staticmethod
    def slim(v):
        keys = ("id", "title", "uid", "nick", "avatar", "cover", "play", "hdplay", "music", "duration",
                "likes", "comments", "shares", "views", "page_url", "region", "author_id")
        return {k: v.get(k) for k in keys if k in v}

    def is_liked(self, vid): return str(vid) in self.liked_ids

    def toggle_like(self, v):
        vid = str(v["id"])
        if vid in self.liked_ids:
            self.liked = [x for x in self.liked if str(x.get("id")) != vid]
            self.liked_ids.discard(vid); on = False
        else:
            self.liked.insert(0, self.slim(v)); self.liked_ids.add(vid); on = True
        save("liked.json", self.liked[:500]); return on

    def is_following(self, uid): return any(x.get("uid") == uid for x in self.following)

    def toggle_follow(self, v):
        uid = v.get("uid")
        if not uid: return False
        if self.is_following(uid):
            self.following = [x for x in self.following if x.get("uid") != uid]; on = False
        else:
            self.following.insert(0, {"uid": uid, "nick": v.get("nick") or uid, "avatar": v.get("avatar")}); on = True
        save("following.json", self.following); return on

    def add_history(self, v):
        vid = str(v["id"])
        self.seen_ids.add(vid)
        self.history = [x for x in self.history if str(x.get("id")) != vid]
        self.history.insert(0, self.slim(v))
        self.history = self.history[:200]
        save("history.json", self.history)

    def comments_for(self, vid):
        return list(self.my_comments.get(str(vid)) or [])

    def add_comment(self, v, text):
        c = {"user": "Bạn (lưu trên máy)", "text": text.strip()[:200], "likes": 0, "replies": 0,
             "mine": True, "ts": int(time.time() * 1000)}
        lst = self.my_comments.setdefault(str(v["id"]), [])
        lst.insert(0, c)
        del lst[50:]
        if len(self.my_comments) > 300:          # keep the file small: drop oldest videos
            for k in list(self.my_comments)[:len(self.my_comments) - 300]:
                self.my_comments.pop(k, None)
        save("comments.json", self.my_comments)
        return c

    def del_comment(self, vid, c):
        lst = [x for x in self.my_comments.get(str(vid), []) if x.get("ts") != c.get("ts")]
        if lst: self.my_comments[str(vid)] = lst
        else: self.my_comments.pop(str(vid), None)
        save("comments.json", self.my_comments)

    def clear_history(self):
        self.history = []; self.seen_ids = set(); save("history.json", [])
