# -*- coding: utf-8 -*-
"""telex.py - small Vietnamese Telex composer (raw keystrokes -> accented text)."""

TONES = {"s": 1, "f": 2, "r": 3, "x": 4, "j": 5}
VOW = {
    "a": "aáàảãạ", "ă": "ăắằẳẵặ", "â": "âấầẩẫậ", "e": "eéèẻẽẹ", "ê": "êếềểễệ",
    "i": "iíìỉĩị", "o": "oóòỏõọ", "ô": "ôốồổỗộ", "ơ": "ơớờởỡợ",
    "u": "uúùủũụ", "ư": "ưứừửữự", "y": "yýỳỷỹỵ",
}
BASE = {}
for b, chars in VOW.items():
    for i, c in enumerate(chars):
        BASE[c] = (b, i)
MODIFIED = set("ăâêôơư")


def _is_vowel(c):
    return c in BASE


def _compose_word(raw):
    """raw letters of ONE word -> composed word"""
    out = []          # list of base chars (with marks, no tone)
    tone = 0
    lit = False
    for ch in raw:
        low = ch.lower()
        up = ch.isupper()
        last = out[-1] if out else ""
        lb = last.lower()

        def put(c):
            out.append(c.upper() if up else c)
        if low in TONES and any(_is_vowel(c.lower()) for c in out) and low != "z":
            t = TONES[low]
            if tone == t:               # same key again -> cancel, type the letter
                tone = 0; put(low)
            else:
                tone = t
            continue
        if low == "z" and tone and any(_is_vowel(c.lower()) for c in out):
            tone = 0; continue
        if low == "d" and lb == "d" and last == "d":
            out[-1] = "đ"; continue
        if low == "d" and lb == "d" and last == "D":
            out[-1] = "Đ"; continue
        if low in "aeo" and lb == low and out:
            m = {"a": "â", "e": "ê", "o": "ô"}[low]
            out[-1] = m.upper() if last.isupper() else m; continue
        if low == "w":
            # apply to previous vowel (a->ă, o->ơ, u->ư) or standalone ư
            idx = len(out) - 1
            if idx >= 0 and lb in ("a", "o", "u"):
                m = {"a": "ă", "o": "ơ", "u": "ư"}[lb]
                out[idx] = m.upper() if last.isupper() else m
                # "uơ" -> "ươ"
                if lb == "o" and idx >= 1 and out[idx - 1].lower() == "u":
                    out[idx - 1] = "Ư" if out[idx - 1].isupper() else "ư"
                continue
            if idx >= 0 and lb == "ơ" and idx >= 1 and out[idx - 1].lower() == "u":
                out[idx - 1] = "Ư" if out[idx - 1].isupper() else "ư"; continue
            if idx >= 0 and lb in ("ă", "ơ", "ư"):          # ww -> w
                put("w"); continue
            put("ư"); continue
        put(low if not up else low)
    # tone placement
    if tone:
        chars = out
        vi = [i for i, c in enumerate(chars) if _is_vowel(c.lower())]
        # treat 'u' after q and 'i' after g (followed by vowel) as consonants
        if len(vi) >= 2:
            f = vi[0]
            if f >= 1 and ((chars[f - 1].lower() == "q" and chars[f].lower() == "u") or
                           (chars[f - 1].lower() == "g" and chars[f].lower() == "i")):
                vi = vi[1:]
        if vi:
            mod = [i for i in vi if chars[i].lower() in MODIFIED]
            if mod:
                tgt = mod[-1]
            elif len(vi) == 1:
                tgt = vi[0]
            elif len(vi) == 2:
                tgt = vi[1] if vi[-1] < len(chars) - 1 else vi[0]   # modern style: hòa, khỏe, thủy
            else:
                tgt = vi[1]
            c = chars[tgt]
            base, _ = BASE[c.lower()]
            nc = VOW[base][tone]
            chars[tgt] = nc.upper() if c.isupper() else nc
    return "".join(out)


def compose(raw):
    """Whole text; words are separated by spaces."""
    return " ".join(_compose_word(w) for w in raw.split(" "))
