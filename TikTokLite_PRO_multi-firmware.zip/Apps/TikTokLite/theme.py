# -*- coding: utf-8 -*-
ACCENTS = {  # key: (label, main, second)
    "tiktok": ("TikTok đỏ", (254, 44, 85), (37, 244, 238)),
    "cyan": ("Xanh ngọc", (37, 244, 238), (254, 44, 85)),
    "purple": ("Tím", (168, 85, 247), (37, 244, 238)),
    "green": ("Xanh lá", (52, 211, 153), (250, 204, 21)),
    "orange": ("Cam", (255, 149, 0), (255, 214, 10)),
    "blue": ("Xanh dương", (59, 130, 246), (236, 72, 153)),
    "pink": ("Hồng", (255, 105, 180), (37, 244, 238)),
}
MODES = {  # key: (label, panel, text, subtext, line)
    "dark": ("Tối", (20, 20, 27), (255, 255, 255), (168, 168, 182), (56, 56, 68)),
    "amoled": ("AMOLED", (0, 0, 0), (255, 255, 255), (160, 160, 172), (40, 40, 48)),
    "light": ("Sáng", (246, 246, 250), (20, 20, 28), (100, 100, 115), (208, 208, 220)),
}


class Theme:
    def __init__(self, cfg):
        a = ACCENTS.get(cfg.get("accent"), ACCENTS["tiktok"])
        m = MODES.get(cfg.get("mode"), MODES["dark"])
        self.acc, self.acc2 = a[1], a[2]
        self.panel, self.fg, self.sub, self.line = m[1], m[2], m[3], m[4]
        self.light = cfg.get("mode") == "light"
        self.alpha = max(40, min(100, int(cfg.get("panel_alpha", 80)))) * 255 // 100

    def c(self, rgb, a=255):
        return (rgb[0], rgb[1], rgb[2], a)

    @property
    def A(self): return self.c(self.acc)
    @property
    def A2(self): return self.c(self.acc2)
    @property
    def P(self): return self.c(self.panel, self.alpha)
    @property
    def PS(self): return self.c(self.panel, 255)
    @property
    def FG(self): return self.c(self.fg)
    @property
    def SUB(self): return self.c(self.sub)
    @property
    def LINE(self): return self.c(self.line)
    @property
    def SEL(self):   # selected-row fill
        return self.c(self.acc, 255) if True else None

    def on_acc(self):
        r, g, b = self.acc
        return (0, 0, 0, 255) if (r * 299 + g * 587 + b * 114) / 1000 > 150 else (255, 255, 255, 255)
