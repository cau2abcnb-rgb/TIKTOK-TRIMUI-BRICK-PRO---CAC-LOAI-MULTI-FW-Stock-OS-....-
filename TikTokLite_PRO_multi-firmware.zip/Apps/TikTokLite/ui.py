#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TikTok By Cau2abc - Trimui Brick Pro

Controller process: talks to mpv through its JSON IPC socket, reads the gamepad,
draws the whole interface (intro, HUD, menus, settings, search, comments) with gfx.py
and pushes it to mpv as bitmap overlays.  mpv on the device has no Lua / libass, which is
why everything lives here instead of in mpv scripts.

usage: ui.py <mpv-ipc-socket>      env: TIKTOK_LOG, TIKTOK_PROXY_PORT, TIKTOK_M3U, TIKTOK_CACHE
exit codes: 0 = user quit, 3 = mpv died, 4 = could not talk to mpv
"""
import os, sys, time, json, select, threading, queue, random, math, hashlib, shutil, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
LOG = os.environ.get("TIKTOK_LOG")


def log(msg):
    if LOG:
        try:
            with open(LOG, "a", encoding="utf-8") as f:
                f.write("ui: %s\n" % msg)
        except Exception:
            pass


import gfx, api, store, netfix
from theme import Theme, ACCENTS, MODES
from mpvipc import Mpv
from pad import Pad
from screens import Screen, Item, ListScreen, SearchScreen, ComposeScreen, CommentsScreen, hints, badge

TITLE = "TikTok By Cau2abc - Trimui Brick Pro"
VERSION = "6.6"
INTRO_SECS = 5.0
BOOT_WAIT = 90            # seconds the start screen keeps waiting for WiFi / server before offering a retry
PORT = int(os.environ.get("TIKTOK_PROXY_PORT", "8808"))
M3U = os.environ.get("TIKTOK_M3U", "/tmp/tiktok.m3u")
CACHE = os.environ.get("TIKTOK_CACHE", os.path.join(HERE, "cache"))
SAVE_DIR = os.environ.get("TIKTOK_SAVE_DIR", "/mnt/SDCARD/Downloads/TikTok")

TOPICS = [("Thịnh hành", "thinhhanh"), ("Xu hướng", "xuhuong"), ("Hài hước", "hài hước"),
          ("Review phim", "review phim"), ("Ẩm thực", "ẩm thực"), ("Nhạc / Cover", "cover"),
          ("Thú cưng", "thú cưng"), ("Du lịch", "du lịch"), ("Bóng đá", "bóng đá"),
          ("Làm đẹp", "làm đẹp"), ("Mẹo vặt", "mẹo vặt"), ("Game", "game"),
          ("Học tiếng Anh", "học tiếng anh"), ("Độ xe", "độ xe"), ("Chữa lành", "chữa lành"),
          ("Khoa học", "khoa học")]

# OV ids
OV_LEFT, OV_RIGHT, OV_PROG, OV_TOAST, OV_ANIM, OV_PAUSE, OV_BACK, OV_SCREEN = 1, 2, 3, 5, 6, 7, 9, 10
OV_INTRO_BG, OV_INTRO = 20, 21


# ============================================================ feed model
class Feed:
    def __init__(self, kind, title, srcs=None, items=None):
        self.kind, self.title = kind, title
        self.srcs = srcs or []            # [{"t": "trend"|"search"|"user", "arg":..., "cur":0, "more":True}]
        self.items = items or []
        self.idx = 0
        self.loading = False
        self.more = bool(self.srcs)
        self.ids = {v["id"] for v in self.items}
        self.fails = 0


def fetch_more(feed, cfg, lib):
    """one network round for a feed -> list of new videos (runs in a worker thread)"""
    batches = []
    region = cfg.get("region", "vietnam")
    first = not feed.items                 # first page: answer as fast as possible, rest loads in the background
    for s in feed.srcs:
        if not s["more"]:
            continue
        if first and batches:
            break
        if s["t"] == "trend":
            vids = api.trending(region, seen=feed.ids, want=4 if first else 14, tries=2 if first else 4)
            s["more"] = True
            batches.append(vids)
        elif s["t"] == "search":
            vids, nxt, more = api.search(s["arg"], s["cur"], 12, region)
            s["cur"], s["more"] = nxt, bool(more and vids)
            batches.append(vids)
        elif s["t"] == "user":
            vids, nxt, more = api.user_posts(s["arg"], s["cur"], 12)
            s["cur"], s["more"] = nxt, bool(more and vids)
            batches.append(vids)
    feed.more = any(s["more"] for s in feed.srcs)
    out, i = [], 0
    while any(i < len(b) for b in batches):         # round-robin merge
        for b in batches:
            if i < len(b):
                out.append(b[i])
        i += 1
    new = [v for v in out if v["id"] not in feed.ids]
    if cfg.get("skip_watched"):
        unseen = [v for v in new if v["id"] not in lib.seen_ids]
        new = unseen or new
    if cfg.get("shuffle"):
        random.shuffle(new)
    for v in new:
        feed.ids.add(v["id"])
    return new


# ============================================================ app
class App:
    def __init__(self, sock):
        self.cfg = store.Settings()
        self.lib = store.Library()
        self.th = Theme(self.cfg)
        self.mpv = Mpv(sock)
        self.pad = Pad()
        self.W = int(os.environ.get("TIKTOK_W", "1024"))
        self.H = int(os.environ.get("TIKTOK_H", "768"))
        self.k = self.H / 768.0
        self.running = True
        self.exit_code = 0
        self.q = queue.Queue()
        self.wake_r, self.wake_w = os.pipe()
        os.set_blocking(self.wake_r, False)
        self.cv_ok = gfx.BACKEND is not None
        # playback state
        self.feed = None
        self.cur = None
        self.pos = self.dur = 0.0
        self.paused = False
        self.paused_by_screen = False
        self.vw = self.vh = 0
        self.eof = False
        self.err_streak = 0
        self.retry_done = False
        self.pending_next = False
        self.auto_id = None
        self.buffering = False
        # ui state
        self.stack = []
        self.held = set()
        self.combo = False
        self.exit_arm = 0
        self.toast_txt, self.toast_until = "", 0
        self.anim = None
        self.hud_until = 0
        self.last_prog = 0
        self.hud_dirty = True
        self.mode = "boot"       # boot | intro | run
        self.intro_t0 = 0
        self.intro_ready = False
        self.intro_fail = False
        self.net_text = "Đang kết nối mạng"
        self.net_stage = ""
        self.boot_gen = 0
        self.bg_drawn = False
        self.last_frame = 0
        self.ov_live = set()
        self.logged_id = None
        self.watch_t0 = 0
        self.backdrop_key = None
        self.hud_hidden = False
        self.ov_checked = False
        self.intro_ms = []

    # ------------------------------------------------ helpers
    def px(self, n): return max(1, int(n * self.k))
    def fs(self, n): return max(9, int(n * self.k * self.cfg["font_scale"] / 100.0))
    def new_cv(self, w, h): return gfx.new_canvas(w, h)

    def post(self, fn):
        self.q.put(fn)
        try: os.write(self.wake_w, b"x")
        except Exception: pass

    def bg(self, work, done=None):
        def run():
            try:
                res = work()
            except Exception as e:
                log("bg error: %r" % (e,)); res = None
            if done:
                self.post(lambda: done(res))
        threading.Thread(target=run, daemon=True).start()

    def toast(self, txt, secs=2.2):
        self.toast_txt, self.toast_until = txt, time.time() + secs
        if self.cv_ok:
            self.render_toast()
        else:
            self.mpv.cmd("show-text", txt, int(secs * 1000))

    # ------------------------------------------------ overlays
    def ov(self, oid, x, y, cv):
        self.mpv.overlay(oid, x, y, cv.w, cv.h, cv.to_bgra(), cb=None if self.ov_checked else self._ov_reply)
        self.ov_checked = True
        self.ov_live.add(oid)

    def _ov_reply(self, m):
        if m.get("error") not in (None, "success"):
            log("overlay-add FAILED: %s -> basic mode" % m.get("error"))
            self.post(self._basic_mode)

    def _basic_mode(self):
        self.cv_ok = False
        self.stack = []
        self.mpv.cmd("show-text", "Che do co ban: mpv nay khong ve duoc giao dien (xem log)", 5000)

    def ov_off(self, *ids):
        for i in ids:
            if i in self.ov_live:
                self.mpv.overlay_remove(i); self.ov_live.discard(i)

    # ------------------------------------------------ video geometry
    def video_rect(self):
        W, H = self.W, self.H
        vw, vh = self.vw or 576, self.vh or 1024
        if self.cfg["rotate"] in (90, 270):
            vw, vh = vh, vw
        fit, fill = min(W / vw, H / vh), max(W / vw, H / vh)
        sc = fit + (fill - fit) * (self.cfg["zoom"] / 100.0)
        dw, dh = min(W, vw * sc), min(H, vh * sc)
        return (W - dw) / 2, (H - dh) / 2, dw, dh

    # ------------------------------------------------ mpv settings
    def apply_video(self, first=False):
        c, m = self.cfg, self.mpv
        m.set("video-rotate", c["rotate"])
        m.set("panscan", c["zoom"] / 100.0)
        m.set("speed", c["speed"] / 100.0)
        m.set("volume", c["volume"])
        m.set("mute", bool(c["mute"]))
        m.set("loop-file", "no" if c["autoscroll"] else "inf")
        perf = {"quality": ("no", "default", "no"), "balanced": ("vo", "nonref", "yes"),
                "smooth": ("decoder+vo", "all", "yes")}.get(c["perf"], ("vo", "nonref", "yes"))
        m.set("framedrop", perf[0]); m.set("vd-lavc-skiploopfilter", perf[1]); m.set("vd-lavc-fast", perf[2])
        self.apply_eq()

    def apply_eq(self):
        c = self.cfg
        m = self.mpv
        m.cmd("vf", "remove", "@eq")
        if c["brightness"] or c["contrast"] or c["saturation"] or c["gamma"]:
            eq = "eq=brightness=%.3f:contrast=%.3f:saturation=%.3f:gamma=%.3f" % (
                c["brightness"] / 100.0, 1 + c["contrast"] / 50.0, max(0.0, 1 + c["saturation"] / 50.0),
                max(0.1, 1 + c["gamma"] / 50.0))
            m.cmd("vf", "add", "@eq:lavfi=[%s]" % eq, cb=self._eq_reply)

    def _eq_reply(self, m):
        if m.get("error") not in (None, "success"):
            self.post(lambda: self.toast("Máy không hỗ trợ chỉnh màu video"))

    def on_settings_changed(self, app=None):
        self.cfg.commit()
        self.th = Theme(self.cfg)
        self.apply_video()
        self.hud_dirty = True
        self.redraw_screen()
        self.render_all_hud()

    # ------------------------------------------------ feed control
    def video_url(self, v):
        base = v.get("hdplay") if (self.cfg["quality"] == "hd" and v.get("hdplay")) else v.get("play")
        if not base:
            return None
        return "http://127.0.0.1:%d/p/%s.mp4?u=%s&tiktok_id=%s" % (PORT, v["id"], urllib.parse.quote(base, safe=""), v["id"])

    def write_m3u(self):
        try:
            with open(M3U + ".tmp", "w", encoding="utf-8") as f:
                f.write("#EXTM3U\n")
                for v in self.feed.items:
                    u = self.video_url(v)
                    if u:
                        f.write("#EXTINF:-1,@%s\n%s\n" % (v.get("uid", ""), u))
            os.replace(M3U + ".tmp", M3U)
        except Exception as e:
            log("m3u: %r" % (e,))

    def open_feed(self, feed, announce=True):
        """load first page of a feed in the background, then start playing it"""
        feed.loading = True
        if announce:
            self.toast("Đang tải: " + feed.title, 30)

        def done(new):
            feed.loading = False
            if new:
                feed.items += new
                self.feed = feed
                self.close_all()
                self.err_streak = 0
                self.toast_until = 0; self.ov_off(OV_TOAST)
                self.play_index(0)
            else:
                self.toast("Không tải được video (%s). Kiểm tra WiFi." % (api.LAST_ERROR[0] or "lỗi mạng"), 4)
                if self.mode == "intro":
                    self.intro_fail = True
        if feed.items:                       # static list (liked / history)
            feed.loading = False
            self.feed = feed
            self.close_all()
            self.play_index(0)
            return
        self.bg(lambda: fetch_more(feed, self.cfg, self.lib), done)

    def feed_more(self):
        f = self.feed
        if not f or f.loading or not f.more:
            return
        f.loading = True

        def done(new):
            f.loading = False
            if new:
                f.items += new; f.fails = 0
                self.write_m3u()
                if self.pending_next:
                    self.pending_next = False
                    self.step(1)
            else:
                f.fails += 1
                if f.fails >= 2: f.more = False
                self.pending_next = False
            self.hud_dirty = True
        self.bg(lambda: fetch_more(f, self.cfg, self.lib), done)

    def play_index(self, i):
        f = self.feed
        if not f or not f.items:
            return
        i = max(0, min(len(f.items) - 1, i))
        f.idx = i
        v = f.items[i]
        self.cur = v
        url = self.video_url(v)
        if not url:
            return self.step(1)
        self.retry_done = False
        self.pos, self.dur = 0.0, float(v.get("duration") or 0)
        self.vw = self.vh = 0
        self.eof = False
        self.watch_t0 = time.time(); self.logged_id = None
        log("play %d/%d id=%s url=%s" % (i + 1, len(f.items), v.get("id"), (v.get("play") or "")[:70]))
        self.mpv.cmd("loadfile", url, "replace")
        self.mpv.set("pause", False)
        self.paused = False
        self.write_m3u()
        self.hud_dirty = True
        self.show_hud()
        if i >= len(f.items) - 8 or len(f.items) < 12:
            self.feed_more()

    def step(self, d):
        f = self.feed
        if not f:
            return
        n = len(f.items)
        i = f.idx + d
        if i >= n:
            if f.more:
                self.pending_next = True
                self.feed_more()
                self.toast("Đang tải thêm video...", 3)
                return
            self.toast("Hết danh sách - quay lại đầu")
            i = 0
        if i < 0:
            self.toast("Đây là video đầu tiên"); return
        self.play_index(i)

    def on_video_error(self, why):
        self.err_streak += 1
        v = self.cur
        log("video error: %s id=%s" % (why, v and v.get("id")))
        if v and not self.retry_done:
            self.retry_done = True

            def fresh(res):
                if res and res.get("play") and self.cur is v:
                    v.update({k: res[k] for k in ("play", "hdplay") if res.get(k)})
                    self.write_m3u()
                    self.mpv.cmd("loadfile", self.video_url(v), "replace")
                elif self.cur is v:
                    self.skip_bad()
            self.bg(lambda: api.resolve(v), fresh)
            return
        self.skip_bad()

    def skip_bad(self):
        if self.err_streak >= 6:
            self.toast("Không phát được video - kiểm tra WiFi rồi nhấn Select+L2 để tải lại", 5)
            return
        self.toast("Video lỗi, chuyển video khác...", 1.5)
        self.step(1)

    # ------------------------------------------------ feeds from menus
    def feed_trending(self):
        return Feed("trend", "Dành cho bạn", [{"t": "trend", "arg": None, "cur": 0, "more": True}])

    def feed_topics(self):
        tps = [t for t in self.cfg["topics"] if t] or ["thinhhanh"]
        if tps == ["thinhhanh"]:
            return self.feed_trending()
        srcs = []
        for t in tps[:3]:
            srcs.append({"t": "trend", "arg": None, "cur": 0, "more": True} if t == "thinhhanh"
                        else {"t": "search", "arg": t, "cur": 0, "more": True})
        label = ", ".join(next((n for n, k in TOPICS if k == t), t) for t in tps[:3])
        return Feed("topics", label, srcs)

    def feed_search(self, q):
        q = q.strip()
        if q.startswith("@") and len(q) > 1:
            return Feed("user", q, [{"t": "user", "arg": q[1:], "cur": 0, "more": True}])
        if q.startswith("#"):
            q2 = q[1:]
            return Feed("search", "#" + q2, [{"t": "search", "arg": q2, "cur": 0, "more": True}])
        return Feed("search", "Tìm: " + q, [{"t": "search", "arg": q, "cur": 0, "more": True}])

    def feed_user(self, uid, nick=None):
        return Feed("user", "@" + uid, [{"t": "user", "arg": uid, "cur": 0, "more": True}])

    def feed_following(self):
        fol = self.lib.following[:6]
        return Feed("following", "Đang theo dõi",
                    [{"t": "user", "arg": f["uid"], "cur": 0, "more": True} for f in fol])

    def reload_current(self):
        f = self.feed
        if not f or f.kind in ("liked", "history"):
            nf = self.feed_topics()
        else:
            nf = Feed(f.kind, f.title, [dict(s, cur=0, more=True) for s in f.srcs])
        self.open_feed(nf)

    def run_search(self, q):
        h = [x for x in self.cfg["search_history"] if x != q]
        self.cfg["search_history"] = ([q] + h)[:8]
        self.cfg.commit()
        self.open_feed(self.feed_search(q))

    # ------------------------------------------------ screens
    def open_screen(self, s):
        if not self.cv_ok:
            self.toast("Thiếu pygame/Pillow - không mở được menu"); return
        if self.stack and self.stack[-1].backdrop and not s.backdrop:
            pass
        self.stack.append(s)
        if s.pause and not self.paused:
            self.mpv.set("pause", True); self.paused_by_screen = True
        s.on_open(self)
        self.hud_dirty = True
        self.render_hud(); self.render_progress(); self.render_pause()
        self.render_backdrop()
        self.redraw_screen()

    def close_screen(self):
        if not self.stack:
            return
        s = self.stack.pop()
        s.on_close(self)
        if not self.stack:
            self.ov_off(OV_SCREEN, OV_BACK)
            self.backdrop_key = None
            if self.paused_by_screen:
                self.mpv.set("pause", False); self.paused_by_screen = False
            self.render_all_hud()
        else:
            if self.paused_by_screen and not any(x.pause for x in self.stack):
                self.mpv.set("pause", False); self.paused_by_screen = False
            elif any(x.pause for x in self.stack) and not self.paused:
                self.mpv.set("pause", True); self.paused_by_screen = True
            self.render_backdrop(); self.redraw_screen()

    def close_all(self):
        while self.stack:
            self.stack.pop().on_close(self)
        self.ov_off(OV_SCREEN, OV_BACK)
        self.backdrop_key = None
        if self.paused_by_screen:
            self.mpv.set("pause", False); self.paused_by_screen = False
        self.render_all_hud()

    def render_backdrop(self):
        s = self.stack[-1] if self.stack else None
        if not s or not s.backdrop:
            self.ov_off(OV_BACK); self.backdrop_key = None; return
        key = (self.W, self.H, self.th.alpha)
        if key == self.backdrop_key:
            return
        cv = self.new_cv(self.W, self.H)
        cv.clear((0, 0, 0, min(210, 90 + self.th.alpha // 3)))
        self.ov(OV_BACK, 0, 0, cv)
        self.backdrop_key = key

    def redraw_screen(self):
        if not self.stack or not self.cv_ok:
            return
        s = self.stack[-1]
        x, y, w, h = s.rect(self)
        cv = self.new_cv(w, h)
        s.draw(self, cv, w, h)
        self.ov(OV_SCREEN, x, y, cv)

    # ---- menu builders
    def menu_hub(self):
        L = self.lib
        items = [
            Item("Dành cho bạn (Thịnh hành)", act=lambda: self.open_feed(self.feed_topics()), icon="play"),
            Item("Đang theo dõi", sub="%d tác giả" % len(L.following), act=self._open_following, icon="user"),
            Item("Khám phá chủ đề", act=lambda: self.open_screen(self.topics_screen()), icon="star"),
            Item("Tìm kiếm", act=self.open_search, icon="search"),
            Item("Đã thích", sub=str(len(L.liked)), act=self._open_liked, icon="heart"),
            Item("Lịch sử xem", sub=str(len(L.history)), act=self._open_history, icon="arrow"),
            Item("Tác giả đã theo dõi", sub=str(len(L.following)), act=lambda: self.open_screen(self.following_screen()), icon="user"),
            Item("Tải lại nguồn video", act=self._reload, icon="download"),
            Item("Cài đặt", act=lambda: self.open_screen(self.settings_root()), icon="gear"),
            Item("Trợ giúp phím", act=lambda: self.open_screen(self.help_screen()), icon="note"),
            Item("Thoát ứng dụng", act=self.quit, icon="pause"),
        ]
        return ListScreen("Menu", items, footer=[("A", "Chọn"), ("B", "Đóng")])

    def _reload(self): self.close_all(); self.reload_current()

    def _open_following(self):
        if not self.lib.following:
            self.toast("Chưa theo dõi ai - nhấn R1 trên video để theo dõi"); return
        self.open_feed(self.feed_following())

    def _open_liked(self):
        if not self.lib.liked:
            self.toast("Chưa có video nào được thích (nhấn X)"); return
        self.open_feed(Feed("liked", "Đã thích", items=[dict(v) for v in self.lib.liked]))

    def _open_history(self):
        if not self.lib.history:
            self.toast("Lịch sử trống"); return
        self.open_feed(Feed("history", "Lịch sử xem", items=[dict(v) for v in self.lib.history]))

    def topics_screen(self):
        items = [Item(n, act=(lambda kw=k: self.open_feed(self.feed_search(kw) if kw != "thinhhanh" else self.feed_trending())))
                 for n, k in TOPICS]
        return ListScreen("Khám phá chủ đề", items, footer=[("A", "Xem"), ("B", "Quay lại")])

    def following_screen(self):
        fol = self.lib.following
        if not fol:
            return ListScreen("Tác giả đã theo dõi", [Item("Chưa theo dõi ai", kind="info"),
                                                       Item("Nhấn R1 trên video rồi chọn Theo dõi", kind="info")])
        items = [Item("@" + f["uid"], sub=f.get("nick") or "", icon="user",
                      act=(lambda u=f["uid"]: self.open_feed(self.feed_user(u)))) for f in fol]
        return ListScreen("Tác giả đã theo dõi", items, footer=[("A", "Xem video"), ("B", "Quay lại")])

    def open_search(self):
        chips = []
        v = self.cur
        if v:
            if v.get("uid"): chips.append(("@" + v["uid"], "@" + v["uid"]))
            tags = []
            for w in (v.get("title") or "").split():
                if w.startswith("#") and len(w) > 1 and w.lower() not in [t.lower() for t in tags]:
                    tags.append(w)
            chips += [(t, t) for t in tags[:4]]
        chips += [(h, h) for h in self.cfg["search_history"][:4]]
        chips += [(n, k) for n, k in TOPICS[:8]]
        self.open_screen(SearchScreen(chips, self.run_search))

    def open_comments(self):
        v = self.cur
        if not v:
            return

        def loader(scr, cursor):
            def done(r):
                if cursor == 0:                       # my own comments (stored on this device) go on top
                    mine = self.lib.comments_for(v["id"])
                    if mine:
                        items, nxt, more = r if r else ([], 0, False)
                        r = (mine + items, nxt, more)
                scr.got(self, r, append=cursor != 0)
            self.bg(lambda: api.comments(v, cursor), done)

        def write(scr):
            def submit(text):
                text = text.strip()
                if not text:
                    return
                self.close_screen()                   # close the keyboard, back to the comment list
                c = self.lib.add_comment(v, text)
                scr.add_local(self, c)
                self.toast("Đã đăng bình luận (lưu trên máy)", 2.5)
            self.open_screen(ComposeScreen(submit))

        def delete(c):
            self.lib.del_comment(v["id"], c)
            self.toast("Đã xóa bình luận của bạn", 1.8)
        self.open_screen(CommentsScreen(v, loader, write, delete))

    def open_creator(self):
        v = self.cur
        if not v:
            return
        info = {"d": None}

        def header(app, cv, x, y, w):
            th, px, fs = app.th, app.px, app.fs
            r = px(30)
            cv.circle(x + r, y + r, r, th.A)
            cv.circle(x + r, y + r, r - px(3), th.PS)
            cv.text(x + r, y + r - fs(15), (v.get("uid") or "?")[:1].upper(), fs(30), th.A, bold=True, anchor="c")
            tx = x + 2 * r + px(14)
            cv.text(tx, y + px(2), cv.fit("@" + (v.get("uid") or ""), fs(22), w - 2 * r - px(20)), fs(22), th.FG, bold=True)
            cv.text(tx, y + px(32), cv.fit(v.get("nick") or "", fs(16), w - 2 * r - px(20)), fs(16), th.SUB)
            d = info["d"]
            if d:
                s = "%s theo dõi  -  %s thích  -  %s video" % (gfx.fmt_num(d["followers"]), gfx.fmt_num(d["likes"]), gfx.fmt_num(d["videos"]))
            else:
                s = "Đang tải thông tin..."
            cv.text(x, y + px(74), cv.fit(s, fs(16), w), fs(16), th.SUB)
            if d and d.get("bio"):
                for i, ln in enumerate(cv.wrap(d["bio"], fs(15), w, 2)):
                    cv.text(x, y + px(98) + i * fs(15) * 1.2, ln, fs(15), th.SUB)
        items = [
            Item("Theo dõi", icon="plus", act=self.toggle_follow, get=None),
            Item("Xem video của tác giả", icon="user", act=lambda: self.open_feed(self.feed_user(v.get("uid", "")))),
            Item("Thích / Bỏ thích", icon="heart", act=lambda: (self.toggle_like(), self._refresh_creator())),
            Item("Tải video về máy", icon="download", act=self.download_current),
            Item("Chia sẻ liên kết", icon="share", act=self.share_current),
            Item("Bình luận", icon="comment", act=lambda: (self.close_screen(), self.open_comments())),
        ]
        scr = ListScreen("Tác giả", items, dock="right", pause=False, backdrop=False, width=470,
                         header=header, header_h=px_h(self, 126), footer=[("A", "Chọn"), ("B", "Đóng")])
        self._creator_scr, self._creator_items = scr, items
        self._refresh_creator()
        self.open_screen(scr)
        uid = v.get("uid")

        def got(d):
            info["d"] = d; self.redraw_screen()
        if uid:
            self.bg(lambda: api.user_info(uid), got)

    def _refresh_creator(self):
        if getattr(self, "_creator_items", None):
            v = self.cur or {}
            self._creator_items[0].label = "Bỏ theo dõi" if self.lib.is_following(v.get("uid")) else "Theo dõi"
            self._creator_items[0].icon = "check" if self.lib.is_following(v.get("uid")) else "plus"
            self.redraw_screen()

    def help_screen(self):
        L = [("Cần trái/phải", "Tua 5 giây"), ("Cần lên/xuống, L2/R2", "Video trước / sau"),
             ("A", "Tạm dừng / phát"), ("X", "Thích video (tim)"), ("L1", "Bình luận"), ("L1 rồi X", "Viết bình luận"),
             ("R1", "Tác giả: theo dõi, tải, chia sẻ"), ("Y", "Menu chính"), ("Start", "Tìm kiếm tiếng Việt (Telex)"),
             ("Select", "Mở bảng trợ giúp này"), ("Select + L2", "Tải lại video mới"),
             ("Select + X", "Theo dõi / bỏ theo dõi nhanh"), ("Select + A", "Bật / tắt tiếng"),
             ("Cần phải lên/xuống", "Âm lượng"), ("Cần phải trái/phải", "Tua video"),
             ("Menu hoặc B (2 lần)", "Thoát ứng dụng")]
        items = [Item("%s :  %s" % (a, b), kind="info") for a, b in L]
        return ListScreen("Trợ giúp phím", items, footer=[("B", "Đóng")], height=650)

    # ---- settings pages
    def _cfg_item(self, label, key, kind, **kw):
        return Item(label, kind=kind, get=lambda: self.cfg[key], set=lambda v: self.cfg.__setitem__(key, v), **kw)

    def settings_root(self):
        items = [
            Item("Video & âm thanh", icon="play", act=lambda: self.open_screen(self.page_video())),
            Item("Giao diện & màu sắc", icon="star", act=lambda: self.open_screen(self.page_theme())),
            Item("Nguồn video & lọc", icon="search", act=lambda: self.open_screen(self.page_source())),
            Item("Dữ liệu & bộ nhớ", icon="save", act=lambda: self.open_screen(self.page_data())),
            Item("Giới thiệu", icon="user", act=lambda: self.open_screen(self.page_about())),
        ]
        return ListScreen("Cài đặt", items, dock="right", pause=False, backdrop=False, width=470,
                          footer=[("A", "Mở"), ("B", "Quay lại")])

    def _page(self, title, items):
        return ListScreen(title, items, dock="right", pause=False, backdrop=False, width=470,
                          on_change=self.on_settings_changed,
                          footer=[("<>", "Đổi"), ("A", "Đặt lại"), ("B", "Lưu")])

    def page_video(self):
        c = self._cfg_item
        sgn = lambda v: "%+d" % v if v else "0"
        items = [
            Item("Hình ảnh", kind="header"),
            c("Xoay màn hình", "rotate", "choice", opts=[(0, "0°"), (90, "90°"), (180, "180°"), (270, "270°")]),
            c("Khung hình", "zoom", "choice", opts=[(0, "Vừa khung"), (50, "Phóng 50%"), (100, "Lấp đầy")]),
            c("Độ sáng", "brightness", "slider", lo=-50, hi=50, step=5, fmt=sgn, default=0),
            c("Tương phản", "contrast", "slider", lo=-50, hi=50, step=5, fmt=sgn, default=0),
            c("Độ bão hòa", "saturation", "slider", lo=-50, hi=50, step=5, fmt=sgn, default=0),
            c("Gamma", "gamma", "slider", lo=-50, hi=50, step=5, fmt=sgn, default=0),
            Item("Đặt lại màu video", act=self._reset_eq),
            Item("Phát", kind="header"),
            c("Tốc độ phát", "speed", "choice", opts=[(50, "0.5x"), (75, "0.75x"), (100, "1x"), (125, "1.25x"), (150, "1.5x"), (200, "2x")]),
            c("Chất lượng video", "quality", "choice", opts=[("sd", "Thường"), ("hd", "HD (nặng)")]),
            c("Hiệu năng", "perf", "choice", opts=[("quality", "Đẹp nhất"), ("balanced", "Cân bằng"), ("smooth", "Mượt nhất")]),
            c("Tự chuyển video khi hết", "autoscroll", "toggle"),
            c("Chuyển nhanh sau", "autoscroll_secs", "choice", opts=[(0, "Hết video"), (4, "4 giây"), (6, "6 giây"), (10, "10 giây"), (15, "15 giây")]),
            Item("Âm thanh", kind="header"),
            c("Âm lượng", "volume", "slider", lo=0, hi=130, step=5, fmt=lambda v: "%d%%" % v, default=80),
            c("Tắt tiếng", "mute", "toggle"),
        ]
        return self._page("Video & âm thanh", items)

    def _reset_eq(self):
        for k in ("brightness", "contrast", "saturation", "gamma"):
            self.cfg[k] = 0
        self.on_settings_changed()
        self.toast("Đã đặt lại màu video")

    def page_theme(self):
        c = self._cfg_item
        items = [
            Item("Màu sắc", kind="header"),
            c("Màu chủ đề", "accent", "choice", opts=[(k, v[0]) for k, v in ACCENTS.items()]),
            c("Chế độ nền", "mode", "choice", opts=[(k, v[0]) for k, v in MODES.items()]),
            c("Độ đậm của bảng", "panel_alpha", "slider", lo=40, hi=100, step=10, fmt=lambda v: "%d%%" % v, default=80),
            c("Cỡ chữ", "font_scale", "slider", lo=80, hi=130, step=10, fmt=lambda v: "%d%%" % v, default=100),
            Item("Màn hình phát", kind="header"),
            c("Kiểu hiển thị", "hud", "choice", opts=[("side", "Hai bên video"), ("over", "Đè lên video"), ("off", "Ẩn hết")]),
            c("Tự ẩn thông tin", "hud_hide", "choice", opts=[(0, "Luôn hiện"), (3, "Sau 3 giây"), (6, "Sau 6 giây")]),
            c("Thanh tiến trình", "show_progress", "toggle"),
            c("Hiện số lượt thích/bình luận", "show_stats", "toggle"),
            Item("Khởi động", kind="header"),
            c("Màn hình mở đầu 5 giây", "intro", "toggle"),
        ]
        return self._page("Giao diện", items)

    def page_source(self):
        c = self._cfg_item

        def topics_toggle(kw):
            def get(): return kw in self.cfg["topics"]

            def set_(on):
                t = [x for x in self.cfg["topics"] if x != kw]
                if on: t.append(kw)
                self.cfg["topics"] = t or ["thinhhanh"]
            return get, set_
        items = [
            Item("Bộ lọc", kind="header"),
            c("Khu vực", "region", "choice", opts=[("vietnam", "Việt Nam"), ("all", "Toàn cầu")]),
            c("Xáo trộn video", "shuffle", "toggle"),
            c("Bỏ qua video đã xem", "skip_watched", "toggle"),
            Item("Chủ đề cho \"Dành cho bạn\"", kind="header"),
        ]
        for n, k in TOPICS:
            g, s = topics_toggle(k)
            items.append(Item(n, kind="toggle", get=g, set=s))
        items.append(Item("Áp dụng và tải lại", act=self._reload, icon="download"))
        return self._page("Nguồn video", items)

    def page_data(self):
        def clear_hist():
            self.lib.clear_history(); self.toast("Đã xóa lịch sử xem")

        def clear_search():
            self.cfg["search_history"] = []; self.cfg.commit(); self.toast("Đã xóa lịch sử tìm kiếm")

        def clear_cache():
            n = 0
            try:
                for f in os.listdir(CACHE):
                    try: os.remove(os.path.join(CACHE, f)); n += 1
                    except Exception: pass
            except Exception:
                pass
            self.toast("Đã xóa %d tệp bộ nhớ đệm" % n)

        def reset_all():
            for k, v in store.DEFAULTS.items():
                self.cfg[k] = v if not isinstance(v, list) else list(v)
            self.on_settings_changed(); self.toast("Đã khôi phục cài đặt mặc định")
        items = [
            Item("Đã thích", sub="%d video" % len(self.lib.liked), kind="info"),
            Item("Đang theo dõi", sub="%d tác giả" % len(self.lib.following), kind="info"),
            Item("Tải về: " + SAVE_DIR, kind="info"),
            Item("Xóa lịch sử xem", act=clear_hist),
            Item("Xóa lịch sử tìm kiếm", act=clear_search),
            Item("Xóa bộ nhớ đệm video", act=clear_cache),
            Item("Khôi phục cài đặt mặc định", act=reset_all),
        ]
        return ListScreen("Dữ liệu", items, dock="right", pause=False, backdrop=False, width=470,
                          footer=[("A", "Chọn"), ("B", "Quay lại")])

    def page_about(self):
        items = [Item(TITLE, kind="info"), Item("Phiên bản " + VERSION, kind="info"),
                 Item("Nguồn video: TikWM (công khai)", kind="info"),
                 Item("Giao diện: " + gfx.BACKEND_NAME + " + font Roboto", kind="info"),
                 Item("Không phải ứng dụng chính thức của TikTok", kind="info")]
        return ListScreen("Giới thiệu", items, dock="right", pause=False, backdrop=False, width=470,
                          footer=[("B", "Quay lại")])

    # ------------------------------------------------ actions
    def toggle_like(self):
        v = self.cur
        if not v:
            return
        on = self.lib.toggle_like(v)
        if on:
            self.anim = {"t0": time.time(), "kind": "heart"}
            self.toast("Đã thích", 1.2)
        else:
            self.toast("Đã bỏ thích", 1.2)
        self.hud_dirty = True; self.render_all_hud()

    def toggle_follow(self):
        v = self.cur
        if not v or not v.get("uid"):
            return
        on = self.lib.toggle_follow(v)
        self.toast(("Đang theo dõi @" if on else "Đã bỏ theo dõi @") + v["uid"], 1.8)
        self.hud_dirty = True; self.render_all_hud(); self._refresh_creator()

    def toggle_pause(self):
        self.paused = not self.paused
        self.mpv.set("pause", self.paused)
        self.render_pause()

    def volume(self, d):
        self.cfg["volume"] = max(0, min(130, self.cfg["volume"] + d))
        self.mpv.set("volume", self.cfg["volume"])
        self.toast("Âm lượng %d%%" % self.cfg["volume"], 1.0)
        self.cfg.commit() if d else None

    def seek(self, d):
        self.mpv.cmd("seek", d, "relative")

    def download_current(self):
        v = self.cur
        if not v:
            return
        self.toast("Đang tải video về máy...", 30)
        base = v.get("hdplay") or v.get("play")

        def work():
            os.makedirs(SAVE_DIR, exist_ok=True)
            name = "%s_%s.mp4" % ((v.get("uid") or "tiktok"), v["id"])
            dest = os.path.join(SAVE_DIR, name)
            if os.path.exists(dest):
                return dest
            cp = os.path.join(CACHE, hashlib.sha1(((v.get("play") or "")).encode()).hexdigest()[:20] + ".mp4")
            tgt = v.get("play") or base
            cp = os.path.join(CACHE, hashlib.sha1(tgt.encode()).hexdigest()[:20] + ".mp4")
            if os.path.exists(cp):
                shutil.copyfile(cp, dest); return dest
            return api.download(base, dest, referer=api.BASE + "/")

        def done(res):
            self.toast(("Đã lưu: " + res) if res else "Tải thất bại", 4)
        self.bg(work, done)

    def share_current(self):
        v = self.cur
        if not v:
            return
        url = v.get("page_url", "")
        try:
            with open(os.path.join(store.DATA, "links.txt"), "a", encoding="utf-8") as f:
                f.write(url + "\n")
        except Exception:
            pass
        items = [Item("Liên kết video:", kind="info")]
        items += [Item(ln, kind="info") for ln in self.new_cv(10, 10).wrap(url, self.fs(18), self.px(520), 4)] if self.cv_ok else []
        items += [Item("", kind="info"), Item("Đã lưu vào data/links.txt trên thẻ nhớ", kind="info")]
        self.open_screen(ListScreen("Chia sẻ", items, footer=[("B", "Đóng")], height=330, pause=False))

    def quit(self):
        self.running = False
        self.mpv.cmd("quit", 0)

    def confirm_exit(self):
        now = time.time()
        if now < self.exit_arm:
            self.quit()
        else:
            self.exit_arm = now + 2.0
            self.toast("Nhấn B hoặc Menu lần nữa để thoát", 2.0)

    # ------------------------------------------------ input
    def show_hud(self):
        h = self.cfg["hud_hide"]
        self.hud_until = time.time() + h if h else 0
        if getattr(self, "hud_hidden", False):
            self.hud_hidden = False
            self.render_all_hud()

    def on_pad(self, name, st):
        if self.mode != "run":
            return
        if st == "down": self.held.add(name)
        elif st == "up": self.held.discard(name)
        self.show_hud()
        if st == "up":
            if name == "select":
                if not self.combo and not self.stack:
                    self.open_screen(self.help_screen())
                self.combo = False
            return
        rep = st == "rep"
        if self.stack:
            self.stack[-1].key(self, name, rep)
            return
        self.feed_key(name, rep)

    def feed_key(self, n, rep):
        sel = "select" in self.held
        if sel and not rep:
            if n == "l2": self.combo = True; self._reload(); return
            if n == "x": self.combo = True; self.toggle_follow(); return
            if n == "a": self.combo = True; self.cfg["mute"] = not self.cfg["mute"]; self.on_settings_changed(); self.toast("Tắt tiếng" if self.cfg["mute"] else "Bật tiếng", 1.2); return
        if n in ("left", "rleft"): self.seek(-5)
        elif n in ("right", "rright"): self.seek(5)
        elif n == "rup": self.volume(5)
        elif n == "rdown": self.volume(-5)
        elif rep: return
        elif n in ("down", "r2"): self.step(1)
        elif n in ("up", "l2"): self.step(-1)
        elif n == "a": self.toggle_pause()
        elif n == "x": self.toggle_like()
        elif n == "y": self.open_screen(self.menu_hub())
        elif n == "start": self.open_search()
        elif n == "l1": self.open_comments()
        elif n == "r1": self.open_creator()
        elif n in ("b", "menu"): self.confirm_exit()

    # ------------------------------------------------ mpv events
    def on_mpv(self, ev):
        e = ev.get("event")
        if e == "property-change":
            nm, val = ev.get("name"), ev.get("data")
            if nm == "time-pos" and val is not None: self.pos = float(val)
            elif nm == "duration" and val: self.dur = float(val)
            elif nm == "pause": self.paused = bool(val)
            elif nm == "width": self.vw = int(val or 0); self.hud_dirty = True
            elif nm == "height": self.vh = int(val or 0); self.hud_dirty = True
            elif nm == "eof-reached" and val and self.cfg["autoscroll"] and self.mode == "run" and not self.stack:
                self.step(1)
            elif nm == "paused-for-cache":
                self.buffering = bool(val)
                if val: self.toast("Đang đệm...", 6)
                elif self.toast_txt == "Đang đệm...": self.toast_until = 0; self.ov_off(OV_TOAST)
            elif nm in ("osd-width", "osd-height") and val:
                if nm == "osd-width" and int(val) != self.W:
                    self.W = int(val); self.relayout()
                if nm == "osd-height" and int(val) != self.H:
                    self.H = int(val); self.relayout()
        elif e == "file-loaded":
            log("file-loaded")
            self.err_streak = 0
            self.mpv.set("pause", self.paused_by_screen or self.paused)
            self.hud_dirty = True
        elif e == "end-file":
            if ev.get("reason") == "error":
                self.on_video_error(ev.get("file_error") or "error")
        elif e == "shutdown":
            self.running = False

    def relayout(self):
        self.k = self.H / 768.0
        self.backdrop_key = None
        self.hud_dirty = True

    # ------------------------------------------------ drawing: HUD
    def render_all_hud(self):
        self.hud_dirty = True
        self.render_hud()
        self.render_progress()
        self.render_pause()

    def feed_tag(self):
        f = self.feed
        return (f.title if f else "") if f else ""

    def draw_info(self, cv, w, h, compact):
        th, px, fs, v = self.th, self.px, self.fs, self.cur
        pad = px(16)
        y = px(16)
        f = self.feed
        if f:
            tag = "%s   %d/%d%s" % (f.title, f.idx + 1, len(f.items), "+" if f.more else "")
            cv.rect(pad, y, min(w - 2 * pad, cv.measure(tag, fs(14), True)[0] + px(22)), px(28), th.A, radius=px(14))
            cv.text(pad + px(11), y + px(5), cv.fit(tag, fs(14), w - 2 * pad - px(22)), fs(14), th.on_acc(), bold=True)
        y += px(46)
        uid = v.get("uid") or ""
        if not compact:
            r = px(26)
            cv.circle(pad + r, y + r, r, th.A)
            cv.circle(pad + r, y + r, r - px(3), th.PS if th.alpha else th.PS)
            cv.text(pad + r, y + r - fs(13), uid[:1].upper() or "?", fs(26), th.A, bold=True, anchor="c")
            tx = pad + 2 * r + px(12)
            cv.text(tx, y + px(2), cv.fit("@" + uid, fs(19), w - tx - pad), fs(19), th.FG, bold=True)
            cv.text(tx, y + px(30), cv.fit(v.get("nick") or "", fs(14), w - tx - pad), fs(14), th.SUB)
            y += px(64)
            fol = self.lib.is_following(uid)
            cw = px(138)
            if fol:
                cv.rect(pad, y, cw, px(30), th.LINE, radius=px(15))
                cv.icon("check", pad + px(10), y + px(5), px(20), th.FG)
                cv.text(pad + px(36), y + px(5), "Đang theo dõi", fs(14), th.FG, bold=True)
            else:
                cv.rect(pad, y, cw, px(30), th.A, radius=px(15))
                cv.icon("plus", pad + px(10), y + px(5), px(20), th.on_acc())
                cv.text(pad + px(36), y + px(5), "Theo dõi", fs(15), th.on_acc(), bold=True)
            y += px(46)
        else:
            cv.text(pad, y - px(6), cv.fit("@" + uid, fs(19), w - 2 * pad), fs(19), th.FG, bold=True)
            y += px(30)
        title = v.get("title") or ""
        words = title.split()
        tags = [x for x in words if x.startswith("#") and len(x) > 1]
        cap = " ".join(x for x in words if not (x.startswith("#") and len(x) > 1)) or ("" if tags else "(không có mô tả)")
        for ln in cv.wrap(cap, fs(17), w - 2 * pad, 3 if compact else 6):
            cv.text(pad, y, ln, fs(17), th.FG); y += int(fs(17) * 1.3)
        for ln in cv.wrap(" ".join(tags), fs(16), w - 2 * pad, 2):
            cv.text(pad, y + px(2), ln, fs(16), th.A, bold=True); y += int(fs(16) * 1.3)
        mus = v.get("music") or ""
        by = h - (px(14) if compact else px(158))
        if mus:
            cv.icon("note", pad, by - px(2), px(22), th.A2)
            cv.text(pad + px(30), by, cv.fit(mus, fs(15), w - 2 * pad - px(32)), fs(15), th.SUB)
        if not compact:
            if self.cfg["show_stats"] and v.get("views"):
                cv.text(pad, by + px(28), "%s lượt xem" % gfx.fmt_num(v["views"]), fs(14), th.SUB)
            hy = h - px(92)
            hints(cv, th, pad, hy, px(24), [("A", "Dừng"), ("X", "Thích")])
            hints(cv, th, pad, hy + px(30), px(24), [("L1", "Bình luận"), ("R1", "Tác giả")])
            hints(cv, th, pad, hy + px(60), px(24), [("Y", "Menu"), ("Start", "Tìm")])

    def draw_rail(self, cv, w, h, compact):
        th, px, fs, v = self.th, self.px, self.fs, self.cur
        cx = w // 2
        liked = self.lib.is_liked(v["id"])
        stats = self.cfg["show_stats"]
        sz = px(46 if compact else 54)
        gap = px(14 if compact else 18)
        n_extra = 0
        items = []
        items.append(("avatar", None, None))
        items.append(("heart", fmt_n(v.get("likes", 0) + (1 if liked else 0)) if stats else "", "X"))
        items.append(("comment", fmt_n(v.get("comments", 0)) if stats else "", "L1"))
        items.append(("share", "Chia sẻ" if not compact else "", "R1"))
        block = (sz + px(28)) + gap
        total = block * len(items)
        y = max(px(10), (h - total) // 2)
        for kind, label, key in items:
            if kind == "avatar":
                r = px(26 if compact else 30)
                cv.circle(cx, y + r, r, th.A)
                cv.circle(cx, y + r, r - px(3), th.PS)
                cv.text(cx, y + r - fs(13), (v.get("uid") or "?")[:1].upper(), fs(26), th.A, bold=True, anchor="c")
                fol = self.lib.is_following(v.get("uid"))
                cv.circle(cx, y + 2 * r, px(11), th.A if not fol else th.LINE)
                cv.icon("check" if fol else "plus", cx - px(8), y + 2 * r - px(8), px(16), th.on_acc() if not fol else th.FG)
                y += 2 * r + px(16) + gap
                continue
            col = th.A if (kind == "heart" and liked) else th.FG
            cv.icon(kind, cx - sz // 2, y, sz, col)
            if label:
                cv.text(cx, y + sz + px(4), label, fs(15), th.FG, bold=True, anchor="c")
            if key and not compact:
                badge(cv, th, max(px(4), cx - px(62)), y + sz // 2 - px(12), key, px(24))
            y += block

    def render_hud(self):
        if not self.cv_ok or self.mode != "run":
            return
        v = self.cur
        mode = self.cfg["hud"]
        hidden = getattr(self, "hud_hidden", False)
        if not v or mode == "off" or hidden or (self.stack and self.stack[-1].backdrop):
            self.ov_off(OV_LEFT, OV_RIGHT); return
        vx, vy, dw, dh = self.video_rect()
        lm = int(vx)
        side = mode == "side" and lm >= self.px(190)
        th = self.th
        if side:
            cv = self.new_cv(lm, self.H); cv.clear(th.PS); self.draw_info(cv, lm, self.H, False); self.ov(OV_LEFT, 0, 0, cv)
            cv = self.new_cv(lm, self.H); cv.clear(th.PS); self.draw_rail(cv, lm, self.H, False); self.ov(OV_RIGHT, self.W - lm, 0, cv)
        else:
            iw = int(min(dw * 0.72, self.px(330)))
            ih = self.px(210)
            cv = self.new_cv(iw, ih); cv.clear((0, 0, 0, 150)); self.draw_info(cv, iw, ih, True)
            self.ov(OV_LEFT, int(vx) + self.px(8), int(vy + dh) - ih - self.px(46), cv)
            rw = self.px(96); rh = self.px(380)
            cv = self.new_cv(rw, rh); cv.clear((0, 0, 0, 120)); self.draw_rail(cv, rw, rh, True)
            self.ov(OV_RIGHT, int(vx + dw) - rw - self.px(6), int(vy + dh) - rh - self.px(50), cv)
        self.hud_dirty = False

    def render_progress(self):
        if not self.cv_ok or self.mode != "run":
            return
        if not self.cfg["show_progress"] or not self.cur or (self.stack and self.stack[-1].backdrop):
            self.ov_off(OV_PROG); return
        vx, vy, dw, dh = self.video_rect()
        w, h = int(dw), self.px(30)
        th = self.th
        cv = self.new_cv(w, h)
        cv.clear((0, 0, 0, 140))
        dur = self.dur or 0
        frac = (self.pos / dur) if dur > 0 else 0
        frac = max(0.0, min(1.0, frac))
        bh = self.px(5)
        cv.rect(0, h - bh, w, bh, (255, 255, 255, 70))
        cv.rect(0, h - bh, int(w * frac), bh, th.A)
        t = "%d:%02d / %d:%02d" % (int(self.pos) // 60, int(self.pos) % 60, int(dur) // 60, int(dur) % 60)
        cv.text(self.px(8), self.px(3), t, self.fs(13), (255, 255, 255, 255))
        if self.cfg["speed"] != 100:
            cv.text(w - self.px(8), self.px(3), "%.2gx" % (self.cfg["speed"] / 100.0), self.fs(13), th.A2, anchor="r", bold=True)
        if self.cfg["mute"]:
            cv.icon("mute", w // 2 - self.px(8), self.px(4), self.px(16), (255, 255, 255, 255))
        self.ov(OV_PROG, int(vx), self.H - h if True else 0, cv)

    def render_toast(self):
        if not self.cv_ok:
            return
        txt = self.toast_txt
        if not txt:
            self.ov_off(OV_TOAST); return
        fs = self.fs(19)
        c0 = self.new_cv(8, 8)
        tw = c0.measure(txt, fs, True)[0]
        w = min(self.W - 40, tw + self.px(44)); h = self.px(46)
        cv = self.new_cv(w, h)
        cv.clear((0, 0, 0, 0))
        cv.rect(0, 0, w, h, (0, 0, 0, 215), radius=h // 2)
        cv.text(w // 2, self.px(10), cv.fit(txt, fs, w - self.px(30)), fs, (255, 255, 255, 255), bold=True, anchor="c")
        self.ov(OV_TOAST, (self.W - w) // 2, self.H - self.px(110), cv)

    def render_pause(self):
        if not self.cv_ok:
            return
        if self.paused and not self.stack and self.cur and self.mode == "run":
            s = self.px(120)
            cv = self.new_cv(s, s)
            cv.clear((0, 0, 0, 0))
            cv.circle(s // 2, s // 2, s // 2, (0, 0, 0, 150))
            cv.icon("play", s // 2 - self.px(22), s // 2 - self.px(28), self.px(56), (255, 255, 255, 255))
            vx, vy, dw, dh = self.video_rect()
            self.ov(OV_PAUSE, int(vx + dw / 2 - s / 2), int(vy + dh / 2 - s / 2), cv)
        else:
            self.ov_off(OV_PAUSE)

    def render_anim(self):
        a = self.anim
        if not a:
            return
        t = time.time() - a["t0"]
        if t > 0.7:
            self.anim = None; self.ov_off(OV_ANIM); return
        s = self.px(190)
        cv = self.new_cv(s, s)
        cv.clear((0, 0, 0, 0))
        sc = 0.55 + 0.6 * math.sin(min(1.0, t / 0.35) * math.pi / 2) if t < 0.35 else 1.15 - 0.15 * min(1.0, (t - 0.35) / 0.35)
        sz = int(s * sc * 0.8)
        cv.icon("heart", (s - sz) // 2, (s - sz) // 2, sz, self.th.A)
        vx, vy, dw, dh = self.video_rect()
        self.ov(OV_ANIM, int(vx + dw / 2 - s / 2), int(vy + dh / 2 - s / 2), cv)

    # ------------------------------------------------ intro
    def intro_bg(self):
        W, H, th = self.W, self.H, self.th
        cv = self.new_cv(W, H)
        for y in range(0, H, 4):
            t = y / float(H)
            r = int(6 + 14 * (1 - t)); g = int(6 + 10 * (1 - t)); b = int(12 + 26 * (1 - t))
            cv.rect(0, y, W, 4, (r, g, b, 255))
        self.ov(OV_INTRO_BG, 0, 0, cv)

    def intro_frame(self, t):
        W, H, th, px, fs = self.W, self.H, self.th, self.px, self.fs
        ch = px(460)
        cv = self.new_cv(W, ch)
        cv.clear((0, 0, 0, 0))
        fade_in = min(1.0, t / 0.8)
        fade_out = 1.0 if not (self.intro_ready and t > INTRO_SECS - 0.5) else max(0.0, (INTRO_SECS - t) / 0.5)
        f = fade_in * fade_out

        def col(c, a=255):
            return (int(c[0] * f), int(c[1] * f), int(c[2] * f), 255)
        cx = W // 2
        # note logo with tiktok-style colour split
        jit = max(0.0, 1.0 - t / 1.4)
        off = px(3) + int(px(14) * jit)
        isz = px(120)
        iy = px(20)
        import random as _r
        sx = int(_r.uniform(-1, 1) * px(10) * jit)
        cv.icon("note", cx - isz // 2 - off + sx, iy - off, isz, col(th.acc2))
        cv.icon("note", cx - isz // 2 + off + sx, iy + off, isz, col(th.acc))
        cv.icon("note", cx - isz // 2 + sx, iy, isz, col((255, 255, 255)))
        # title
        ty = iy + isz + px(10)
        size = fs(96)
        w1 = cv.measure("TikTok", size, True)[0]
        tx = cx - w1 // 2
        cv.text(tx - off + sx, ty - off, "TikTok", size, col(th.acc2), bold=True)
        cv.text(tx + off + sx, ty + off, "TikTok", size, col(th.acc), bold=True)
        cv.text(tx + sx, ty, "TikTok", size, col((255, 255, 255)), bold=True)
        # subtitle typewriter
        sub = "By Cau2abc - Trimui Brick Pro"
        n = int(max(0.0, min(1.0, (t - 1.0) / 1.8)) * len(sub))
        sy = ty + size + px(26)
        full = cv.measure(sub, fs(30), True)[0]
        cv.text(cx - full // 2, sy, sub[:n], fs(30), col((255, 255, 255)), bold=True)
        if n < len(sub) and int(t * 4) % 2 == 0:
            cv.rect(cx - full // 2 + cv.measure(sub[:n], fs(30), True)[0] + px(3), sy + px(2), px(3), fs(30), col(th.acc))
        # equaliser bars
        bars = 28
        bw = px(10); gap = px(8)
        bx0 = cx - (bars * (bw + gap)) // 2
        by = ch - px(86)
        for i in range(bars):
            hh = px(8) + int((math.sin(t * 6 + i * 0.7) * 0.5 + 0.5) * px(46) * (0.4 + 0.6 * min(1.0, t / 1.5)))
            cv.rect(bx0 + i * (bw + gap), by - hh, bw, hh, col(th.acc if i % 2 == 0 else th.acc2), radius=px(3))
        # progress bar + status
        pw = px(420)
        py = ch - px(40)
        cv.rect(cx - pw // 2, py, pw, px(8), (int(60 * f), int(60 * f), int(72 * f), 255), radius=px(4))
        if t < INTRO_SECS or self.intro_ready:
            cv.rect(cx - pw // 2, py, int(pw * min(1.0, t / INTRO_SECS)), px(8), col(th.acc), radius=px(4))
        else:                                   # still waiting for the network: moving segment
            seg = pw // 3
            x0 = int(((t * 0.7) % 1.0) * (pw + seg)) - seg
            a, b = max(0, x0), min(pw, x0 + seg)
            if b > a:
                cv.rect(cx - pw // 2 + a, py, b - a, px(8), col(th.acc), radius=px(4))
        dots = "." * (int(t * 3) % 4)
        waiting = t >= INTRO_SECS and not self.intro_ready
        msg = (self.net_text if (waiting or self.net_stage not in ("", "ok")) else "Đang khởi động") + dots
        if waiting:
            msg += "  (%ds)" % int(t - INTRO_SECS)
        cv.text(cx, py + px(14), msg, fs(16), col(th.acc2 if (self.net_stage not in ("", "ok") and waiting) else (170, 170, 185)), anchor="c")
        self.ov(OV_INTRO, 0, (H - ch) // 2, cv)

    # ------------------------------------------------ boot
    def start(self):
        if not self.mpv.connect(20):
            log("cannot connect to mpv"); return 4
        for i, n in enumerate(("time-pos", "duration", "pause", "width", "height", "eof-reached",
                               "paused-for-cache", "osd-width", "osd-height"), 1):
            self.mpv.observe(i, n)
        self.apply_video(first=True)
        time.sleep(0.15)
        for ev in self.mpv.read():
            self.on_mpv(ev)
        log("start: screen %dx%d backend=%s" % (self.W, self.H, gfx.BACKEND_NAME))
        netfix.install()
        self.mode = "intro"
        self.intro_t0 = time.time()
        self.boot_begin()
        if not self.cv_ok:
            self.mpv.cmd("show-text", TITLE, int(INTRO_SECS * 1000))
        return self.loop()

    def boot_begin(self):
        """load the first page in the background; waits for WiFi/DNS and retries by itself (no restart, no new logo)"""
        feed = self.feed_topics()
        self.boot_feed = feed
        self.boot_gen += 1
        gen = self.boot_gen
        self.intro_ready = self.intro_fail = False
        self.net_text, self.net_stage = "Đang kết nối mạng", ""
        feed.loading = True

        def worker():
            t0, kicked, n = time.time(), False, 0
            while self.running and gen == self.boot_gen and time.time() - t0 < BOOT_WAIT:
                stage, text = netfix.status()
                self.net_stage, self.net_text = stage, text
                if stage != "ok":
                    if stage in ("noip", "nolink") and not kicked and time.time() - t0 > 4:
                        kicked = True; netfix.kick_wifi()
                    time.sleep(1.0); continue
                for s in feed.srcs:
                    s["more"] = True; s["cur"] = 0
                try:
                    new = fetch_more(feed, self.cfg, self.lib)
                except Exception as e:
                    log("boot fetch error: %r" % (e,)); new = []
                if new:
                    def ok(new=new):
                        if gen != self.boot_gen: return
                        feed.loading = False
                        feed.items += new
                        self.feed = feed
                        self.intro_ready = True
                        self.write_m3u()
                    self.post(ok); return
                n += 1
                self.net_text = "Máy chủ TikTok chưa phản hồi, thử lại lần %d..." % n
                log("boot: server gave no videos (%s), retry %d" % (api.LAST_ERROR[0], n))
                time.sleep(2.0)
            if gen == self.boot_gen:
                self.post(lambda: setattr(self, "intro_fail", True))
        threading.Thread(target=worker, daemon=True).start()

    def restart_boot(self):
        """'Thu lai' on the failure screen: back to the waiting screen, without replaying the 5 s logo"""
        self.close_all()
        self.mode = "intro"
        self.intro_t0 = time.time() - INTRO_SECS
        self.bg_drawn = False
        self.boot_begin()

    def intro_tick(self):
        t = time.time() - self.intro_t0
        waiting = not (self.intro_ready or self.intro_fail)
        min_t = INTRO_SECS if self.cfg["intro"] else 0.0
        show = self.cv_ok and (self.cfg["intro"] or (waiting and t > 1.0))
        if show and not self.bg_drawn:
            self.intro_bg(); self.bg_drawn = True
        if show and time.time() - self.last_frame > 0.09:
            self.last_frame = time.time()
            t1 = time.time()
            self.intro_frame(t)
            self.intro_ms.append(int((time.time() - t1) * 1000))
        if t >= min_t and (self.intro_ready or self.intro_fail):
            self.ov_off(OV_INTRO, OV_INTRO_BG)
            self.bg_drawn = False
            log("intro done: frames=%d avg_ms=%d ready=%s fail=%s net=%s err=%s" % (len(self.intro_ms), sum(self.intro_ms) // max(1, len(self.intro_ms)), self.intro_ready, self.intro_fail, self.net_stage, api.LAST_ERROR[0]))
            self.mode = "run"
            self.feed = self.boot_feed
            if self.intro_ready:
                self.play_index(0)
            else:
                self.render_all_hud()
                self.fail_screen()

    def fail_screen(self):
        items = [Item("Thử lại (chờ WiFi)", act=self.restart_boot, icon="download"),
                 Item("Cài đặt", act=lambda: self.open_screen(self.settings_root()), icon="gear"),
                 Item("Thoát", act=self.quit, icon="pause")]
        msg = "%s (%s)" % (self.net_text, api.LAST_ERROR[0] or self.net_stage or "WiFi")
        self.open_screen(ListScreen("Mất kết nối", [Item(msg, kind="info")] + items, footer=[("A", "Chọn")], height=380))

    # ------------------------------------------------ main loop
    def tick(self):
        now = time.time()
        if self.mode == "intro":
            self.intro_tick(); return
        if self.toast_until and now > self.toast_until:
            self.toast_until = 0; self.toast_txt = ""; self.ov_off(OV_TOAST)
        if self.anim:
            self.render_anim()
        if self.stack:
            if self.stack[-1].tick(self): self.redraw_screen()
        elif now - self.last_prog > 0.33 and not self.paused:
            self.last_prog = now
            self.render_progress()
        secs = self.cfg["autoscroll_secs"]
        if (secs and self.cfg["autoscroll"] and self.mode == "run" and not self.stack and not self.paused
                and self.cur and self.pos >= secs and self.auto_id != self.cur["id"]):
            self.auto_id = self.cur["id"]          # skim mode: jump to the next video after `secs` seconds
            self.step(1)
        if self.cur and self.logged_id != self.cur["id"] and now - self.watch_t0 > 3 and self.pos > 0.5:
            self.logged_id = self.cur["id"]; self.lib.add_history(self.cur)
        h = self.cfg["hud_hide"]
        if h and self.hud_until and now > self.hud_until and not self.stack and not getattr(self, "hud_hidden", False):
            self.hud_hidden = True; self.render_hud()
        if self.hud_dirty and self.mode == "run" and not (self.stack and self.stack[-1].backdrop):
            self.render_hud()
            self.render_progress()

    def loop(self):
        while self.running:
            rl = [self.wake_r]
            if self.mpv.alive: rl.append(self.mpv.fileno())
            pf = self.pad.fileno()
            if pf >= 0: rl.append(pf)
            try:
                r, _, _ = select.select(rl, [], [], 0.04)
            except Exception:
                r = []
            if self.wake_r in r:
                try: os.read(self.wake_r, 4096)
                except Exception: pass
            while True:
                try: fn = self.q.get_nowait()
                except queue.Empty: break
                try: fn()
                except Exception as e: log("task error: %r" % (e,))
            for ev in self.mpv.read():
                try: self.on_mpv(ev)
                except Exception as e: log("mpv ev error: %r" % (e,))
            if not self.mpv.alive:
                log("mpv gone"); return 0 if not self.running else 3
            if self.pad.fileno() < 0 or pf in r or True:
                for n, st in self.pad.read() + self.pad.repeats():
                    try: self.on_pad(n, st)
                    except Exception as e:
                        import traceback; log("pad error: %s" % traceback.format_exc())
            try: self.tick()
            except Exception:
                import traceback; log("tick error: %s" % traceback.format_exc())
        return self.exit_code


def fmt_n(n): return gfx.fmt_num(n)
def px_h(app, n): return app.px(n)


def main():
    sock = sys.argv[1] if len(sys.argv) > 1 else "/tmp/tiktok_mpv.sock"
    be = gfx.init_backend()
    log("gfx backend: %s probe_errors=%s" % (gfx.BACKEND_NAME, gfx.PROBE_ERR))
    app = App(sock)
    app.cv_ok = be is not None
    try:
        rc = app.start()
    except KeyboardInterrupt:
        rc = 0
    except Exception:
        import traceback; log("FATAL: " + traceback.format_exc()); rc = 3
    try:
        app.mpv.cmd("quit", 0) if rc == 0 else None
    except Exception:
        pass
    sys.exit(rc)


if __name__ == "__main__":
    main()
