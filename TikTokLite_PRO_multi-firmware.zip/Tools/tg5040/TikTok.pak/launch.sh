#!/bin/sh
# TikTok By Cau2abc - Trimui Brick Pro: thin launcher, the program lives in Apps/TikTokLite
HERE="$(cd "$(dirname "$0")" && pwd)"
for d in "$HERE/../../../Apps/TikTokLite" "${SDCARD_PATH:-/mnt/SDCARD}/Apps/TikTokLite" /mnt/SDCARD/Apps/TikTokLite \
         /userdata/roms/ports/TikTokLite /userdata/roms/TikTokLite; do
    if [ -f "$d/launch.sh" ]; then exec sh "$d/launch.sh"; fi
done
echo "TikTokLite: khong tim thay thu muc Apps/TikTokLite (hay chep ca thu muc Apps/TikTokLite vao the nho)" >&2
exit 1
